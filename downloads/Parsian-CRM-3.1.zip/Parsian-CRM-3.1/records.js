import { date, fail, now, text, today } from './domain.js';

export const TONNAGES = [100,160,220,320,420,550,800,1300];
export const SOURCES = ['معرف','نمایشگاه','سایت','اینستاگرام'];
const profileFields = ['name','phone','company','position','firstContact','source','referrer','address','industry','product'];
export function validateSource(row) {
  if (!SOURCES.includes(row.source)) fail('نحوه آشنایی را انتخاب کنید.');
  if (row.source === 'معرف' && !row.referrer) fail('نام معرف الزامی است.');
  if (row.source !== 'معرف') row.referrer = '';
}
export function records(db, { customer, task, transaction, createLead }) {
  function audit(u, entity, id, action, before, after) {
    db.prepare('INSERT INTO audit(actor,entity,target,action,previous,value,created) VALUES(?,?,?,?,?,?,?)')
      .run(u.id,entity,id,action,JSON.stringify(before ?? null),JSON.stringify(after ?? null),now());
  }
  function buyer(id) {
    const r=db.prepare('SELECT * FROM buyers WHERE id=?').get(id);
    if (!r) fail('مشتری پیدا نشد.',404);
    return {...JSON.parse(r.data),id:r.id,salesId:r.sales_id};
  }
  function allowed(u,b,write=false) {
    if (!(u.role==='manager' || (!write && u.role==='director') || (u.role==='sales' && u.id===b.salesId))) fail('دسترسی به پرونده مشتری مجاز نیست.',403);
  }
  function missing(b) {
    return profileFields.filter(k=>k!=='referrer'&&!b[k]).length || !SOURCES.includes(b.source) || (b.source==='معرف'&&!b.referrer);
  }
  function storeBuyer(row,owner) {
    return Number(db.prepare('INSERT INTO buyers(data,sales_id) VALUES(?,?)').run(JSON.stringify(row),owner).lastInsertRowid);
  }
  function profile(body,old={}) {
    const row=Object.fromEntries(profileFields.map(k=>[k,text(body[k]??old[k])]));
    validateSource(row);
    if (missing(row)) fail('اطلاعات پروفایل مشتری را کامل کنید.');
    row.firstContact=date(row.firstContact);
    if (!/^\+?\d{7,15}$/.test(row.phone)) fail('شماره تماس معتبر وارد کنید.');
    return row;
  }
  function buyerList(u) {
    if (!['sales','manager','director'].includes(u.role)) return [];
    return db.prepare('SELECT id FROM buyers ORDER BY id DESC').all().map(r=>buyer(r.id)).filter(b=>u.role!=='sales'||b.salesId===u.id).map(b=>({...b,contracts:db.prepare('SELECT * FROM contracts WHERE buyer_id=? ORDER BY id DESC').all(b.id).map(r=>({...JSON.parse(r.data),id:r.id,leadId:r.lead_id}))}));
  }
  function writeBuyer(u,id,body) {
    return transaction(()=>{
      let target=id;
      const old=id?buyer(id):{};
      const owner=id?old.salesId:(u.role==='sales'?u.id:Number(body.salesId));
      allowed(u,{salesId:owner},true);
      if (!id && !db.prepare("SELECT id FROM users WHERE id=? AND role='sales' AND active=1").get(owner)) fail('کارشناس فروش فعال انتخاب کنید.');
      const row=profile(body,old);
      if(id) db.prepare('UPDATE buyers SET data=? WHERE id=?').run(JSON.stringify(row),id);
      else target=storeBuyer(row,owner);
      profileTasks(target);
      audit(u,'مشتری',target,id?'ویرایش پروفایل':'ثبت مشتری',id?old:null,row);
      return {id:target};
    });
  }
  function profileTasks(id) {
    const b=buyer(id);
    for (const link of db.prepare('SELECT id,lead_id,data FROM contracts WHERE buyer_id=? AND lead_id IS NOT NULL').all(id)) {
      const open=db.prepare("SELECT id FROM tasks WHERE customer_id=? AND kind='profile' AND state='open'").get(link.lead_id);
      const incomplete=missing(b)||!JSON.parse(link.data).complete;
      if(incomplete&&!open) task(link.lead_id,b.salesId,'profile','تکمیل پرونده مشتری و قرارداد',today());
      if(!incomplete&&open) db.prepare("UPDATE tasks SET state='done' WHERE id=?").run(open.id);
    }
  }
  function convert(c,day) {
    if(!c.buyerId) {
      const fields=Object.fromEntries(profileFields.map(k=>[k,c[k]||'']));
      c.buyerId=storeBuyer(fields,c.salesId);
    }
    if(!db.prepare('SELECT id FROM contracts WHERE lead_id=?').get(c.id)) {
      const row={signed:day,delivery:'',actualDelivery:'',payment:'',devices:(c.devices||[]).map(d=>({tonnage:d.tonnage,technicalFeatures:d.technicalFeatures||''})),complete:false};
      db.prepare('INSERT INTO contracts(buyer_id,lead_id,sales_id,data) VALUES(?,?,?,?)').run(c.buyerId,c.id,c.salesId,JSON.stringify(row));
    }
    profileTasks(c.buyerId);
  }
  function writeContract(u,id,cid,body) {
    return transaction(()=>{
      const b=buyer(id);allowed(u,b,true);
      const old=cid?db.prepare('SELECT data FROM contracts WHERE id=? AND buyer_id=?').get(cid,id):null;
      if(cid&&!old) fail('قرارداد پیدا نشد.',404);
      const row={signed:date(body.signed),delivery:date(body.delivery),actualDelivery:body.actualDelivery?date(body.actualDelivery):'',payment:text(body.payment),complete:true};
      if(row.delivery<row.signed || (row.actualDelivery&&row.actualDelivery<row.signed)) fail('تاریخ تحویل قبل از قرارداد است.');
      if(!row.payment||!Array.isArray(body.devices)||!body.devices.length||body.devices.length>30) fail('دستگاه‌ها و نحوه پرداخت لازم است.');
      row.devices=body.devices.map(d=>{
        const tonnage=Number(d?.tonnage), technicalFeatures=text(d?.technicalFeatures);
        if(!Number.isFinite(tonnage)||tonnage<=0||!technicalFeatures) fail('تناژ و مشخصات فنی دستگاه را وارد کنید.');
        return {tonnage,technicalFeatures};
      });
      let target=cid;
      if(cid) db.prepare('UPDATE contracts SET data=? WHERE id=?').run(JSON.stringify(row),cid);
      else target=Number(db.prepare('INSERT INTO contracts(buyer_id,sales_id,data) VALUES(?,?,?)').run(id,b.salesId,JSON.stringify(row)).lastInsertRowid);
      audit(u,'قرارداد',target,cid?'ویرایش قرارداد':'ثبت قرارداد',old&&JSON.parse(old.data),row);profileTasks(id);
      return {id:target};
    });
  }
  function repeat(u,id) {
    return transaction(()=>{
      const b=buyer(id);allowed(u,b,true);
      const active=db.prepare("SELECT id FROM customers WHERE json_extract(data,'$.buyerId')=? AND json_extract(data,'$.stage') NOT IN ('won','lost')").get(id);
      if(active)fail('درخواست خرید باز برای این مشتری وجود دارد.',409);
      const result=createLead(u,{...b,registrationNotes:'درخواست خرید مجدد'},id);
      audit(u,'مشتری',id,'درخواست خرید مجدد',null,result.customer.code);return result;
    });
  }
  function removeLead(u,id) {
    if(u.role!=='manager')fail('حذف متقاضی فقط با مدیر فروش است.',403);
    return transaction(()=>{
      const c=customer(id);
      db.prepare('DELETE FROM tasks WHERE customer_id=?').run(id);
      db.prepare('DELETE FROM events WHERE customer_id=?').run(id);
      db.prepare('DELETE FROM customers WHERE id=?').run(id);
      audit(u,'متقاضی',id,'حذف کامل پرونده',c.code,null);return {ok:true};
    });
  }
  return {audit,buyerList,writeBuyer,writeContract,convert,repeat,removeLead};
}
