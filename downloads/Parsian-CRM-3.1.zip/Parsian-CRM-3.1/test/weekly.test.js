import { test } from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {weeklyTracker} from '../weekly.js';
test('Friday closing captures each open overdue task once and freezes historical owner and delay',()=>{
 const db=new DatabaseSync(':memory:');
 db.exec(`CREATE TABLE users(id,name,role,active); CREATE TABLE tasks(id,customer_id,owner_id,kind,title,due,state);
 INSERT INTO users VALUES(1,'سارا','sales',1),(2,'علی','technical',1);
 INSERT INTO tasks VALUES(1,4,1,'followup','تماس','2026-11-18','open'),(2,4,2,'technical','مشاوره','2026-11-20','open'),(3,4,1,'visit','بازدید','2026-11-21','open'),(4,4,1,'visit','بازدید','2026-11-15','paused');`);
 let day='2026-11-20';
 const w=weeklyTracker(db,()=>day);w.capture();assert.deepEqual(w.reports(),[]);
 day='2026-11-21';w.capture();
 db.exec("UPDATE tasks SET state='done';UPDATE users SET name='نام جدید'");
 day='2026-11-28';w.capture();w.capture();
 const [latest,old]=w.reports();assert.equal(old.friday,'2026-11-20');
 assert.deepEqual(old.owners.map(o=>o.tasks.map(t=>t.days)),[[3],[1]]);
 assert.equal(old.owners[0].name,'سارا');assert.ok(latest.owners.every(o=>o.tasks.length===0));
 db.close();
});
