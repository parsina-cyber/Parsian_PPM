// The service owns CRM writes. Capture a closed week before its first subsequent
// mutation, including after downtime. Never infer weeks preceding installation.
const DAY = 86400000;
const tehran = new Intl.DateTimeFormat('en-CA', {timeZone:'Asia/Tehran'});
function shift(day,n) {return new Date(Date.parse(day)+n*DAY).toISOString().slice(0,10);}
function lastClosedFriday(day) {
  const weekday=new Date(day+'T12:00:00Z').getUTCDay();
  return shift(day,-((weekday+1)%7+1));
}
export function weeklyTracker(db, clock=()=>tehran.format(new Date())) {
  db.exec('CREATE TABLE IF NOT EXISTS weekly_overdue(friday TEXT PRIMARY KEY, report TEXT NOT NULL); CREATE TABLE IF NOT EXISTS weekly_origin(id INTEGER PRIMARY KEY CHECK(id=1), start_after TEXT NOT NULL)');
  db.prepare('INSERT OR IGNORE INTO weekly_origin VALUES(1,?)').run(lastClosedFriday(clock()));
  function capture(){
    const end=lastClosedFriday(clock());
    const last=db.prepare('SELECT coalesce(max(friday),(SELECT start_after FROM weekly_origin)) AS day FROM weekly_overdue').get().day;
    for(let friday=shift(last,7);friday<=end;friday=shift(friday,7)){
      const owners=db.prepare("SELECT id,name,role FROM users WHERE role IN ('sales','technical') AND (active=1 OR EXISTS (SELECT 1 FROM tasks WHERE owner_id=users.id AND state='open')) ORDER BY id").all();
      const tasks=db.prepare("SELECT id,customer_id,owner_id,kind,title,due FROM tasks WHERE state='open' AND due<=? ORDER BY owner_id,due,id").all(friday);
      const groups=owners.map(u=>({...u,tasks:tasks.filter(t=>t.owner_id===u.id).map(t=>({...t,days:1+(Date.parse(friday)-Date.parse(t.due))/DAY}))}));
      db.prepare('INSERT INTO weekly_overdue VALUES(?,?)').run(friday,JSON.stringify(groups));
    }
  }
  function reports(){return db.prepare('SELECT friday,report FROM weekly_overdue ORDER BY friday DESC').all().map(r=>({friday:r.friday,owners:JSON.parse(r.report)}));}
  return {capture,reports};
}
