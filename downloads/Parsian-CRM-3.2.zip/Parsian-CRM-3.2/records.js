import {paymentPlan,totals} from './finance.js';
import { date, fail, now, text, today } from './domain.js';

export const TONNAGES = [100,160,220,320,420,550,800,1300];
export const SOURCES = ['معرف','نمایشگاه','سایت','اینستاگرام'];
const profileFields = ['name','phone','company','position','firstContact','source','referrer','address','industry','product'];
export function validateSource(row) {
  if (!SOURCES.includes(row.source)) fail('نحوه آشنایی را انتخاب کنید.');
  if (row.source === 'معرف' && !row.referrer) fail('نام معرف الزامی است.');
  if (row.source !== 'معرف') row.referrer = '';
}
export function records(db, { customer, task, transaction, createLead }) {
  function audit(u, entity, id, action, before, after) {
    db.prepare('INSERT INTO audit(actor,entity,target,action,previous,value,created) VALUES(?,?,?,?,?,?,?)')
      .run(u.id,entity,id,action,JSON.stringify(before ?? null),JSON.stringify(after ?? null),now());
  }
  function buyer(id) {
    const r=db.prepare('SELECT * FROM buyers WHERE id=?').get(id);
    if (!r) fail('مشتری پیدا نشد.',404);
    return {...JSON.parse(r.data),id:r.id,salesId:r.sales_id};
  }
  function allowed(u,b,write=false) {
    if (!(u.role==='manager' || (!write && u.role==='director') || (u.role==='sales' && u.id===b.salesId))) fail('دسترسی به پرونده مشتری مجاز نیست.',403);
  }
  function missing(b) {
    return profileFields.filter(k=>k!=='referrer'&&!b[k]).length || !SOURCES.includes(b.source) || (b.source==='معرف'&&!b.referrer);
  }
  function storeBuyer(row,owner) {
    return Number(db.prepare('INSERT INTO buyers(data,sales_id) VALUES(?,?)').run(JSON.stringify(row),owner).lastInsertRowid);
  }
  function profile(body,old={},legacy=false) {
    const row=Object.fromEntries(profileFields.map(k=>[k,text(body[k]??old[k])]));
    if(row.source||!legacy)validateSource(row);else row.referrer='';
    if (!row.name||!row.address||(!legacy&&missing(row))) fail('اطلاعات پروفایل مشتری را کامل کنید.');
    if(row.firstContact)row.firstContact=date(row.firstContact);
    if (row.phone&&!/^\+?\d{7,15}$/.test(row.phone)) fail('شماره تماس معتبر وارد کنید.');
    return {...row,legacy};
  }
  function buyerList(u) {
    if (!['sales','manager','director'].includes(u.role)) return [];
    return db.prepare('SELECT id FROM buyers ORDER BY id DESC').all().map(r=>buyer(r.id)).filter(b=>u.role!=='sales'||b.salesId===u.id).map(b=>({...b,contracts:listRecords(b,'contracts'),services:listRecords(b,'services')}));
  }
  function saveBuyer(u,id,body) {
      let target=id;
      const old=id?buyer(id):{};
      const owner=u.role==='sales'?u.id:(body.salesId!==undefined&&(!id||old.salesId==null)?Number(body.salesId)||null:old.salesId??null);
      if(id)allowed(u,old,true);
      allowed(u,{salesId:owner},true);
      if (owner && (!id||owner!==old.salesId) && !db.prepare("SELECT id FROM users WHERE id=? AND role='sales' AND active=1").get(owner)) fail('کارشناس فروش فعال انتخاب کنید.');
      const row=profile(body,old,!id||old.legacy||old.salesId==null);
      if(id) db.prepare('UPDATE buyers SET data=?,sales_id=? WHERE id=?').run(JSON.stringify(row),owner,id);
      else target=storeBuyer(row,owner);
      profileTasks(target);
      audit(u,'مشتری',target,id?'ویرایش پروفایل':'ثبت مشتری',id?old:null,row);
      return {id:target};
  }
  function writeBuyer(u,id,body){return transaction(()=>saveBuyer(u,id,body));}
  function profileTasks(id) {
    const b=buyer(id);
    for (const link of db.prepare('SELECT id,lead_id,data FROM contracts WHERE buyer_id=? AND lead_id IS NOT NULL').all(id)) {
      const open=db.prepare("SELECT id FROM tasks WHERE customer_id=? AND kind='profile' AND state='open'").get(link.lead_id);
      const incomplete=missing(b)||!JSON.parse(link.data).complete;
      if(incomplete&&!open) task(link.lead_id,b.salesId,'profile','تکمیل پرونده مشتری و قرارداد',today());
      if(!incomplete&&open) db.prepare("UPDATE tasks SET state='done' WHERE id=?").run(open.id);
    }
  }
  function convert(c,day) {
    if(!c.buyerId) {
      const fields=Object.fromEntries(profileFields.map(k=>[k,c[k]||'']));
      c.buyerId=storeBuyer(fields,c.salesId);
    }
    if(!db.prepare('SELECT id FROM contracts WHERE lead_id=?').get(c.id)) {
      const row={signed:day,delivery:'',actualDelivery:'',payment:'',devices:(c.devices||[]).map(d=>({tonnage:d.tonnage,technicalFeatures:d.technicalFeatures||''})),complete:false};
      db.prepare('INSERT INTO contracts(buyer_id,lead_id,sales_id,data) VALUES(?,?,?,?)').run(c.buyerId,c.id,c.salesId,JSON.stringify(row));
    }
    profileTasks(c.buyerId);
  }
  function revision(previous,submitted){
    const current=previous?.revision||0;
    if(submitted!==undefined&&Number(submitted)!==current)fail('این پرونده هم‌زمان تغییر کرده است. اطلاعات را به‌روز کنید و دوباره ویرایش کنید.',409);
    return current+1;
  }
  function writeContract(u,id,cid,body) {
    return transaction(()=>{
      const b=buyer(id);allowed(u,b,true);
      const old=cid?db.prepare('SELECT data FROM contracts WHERE id=? AND buyer_id=?').get(cid,id):null;
      if(cid&&!old) fail('قرارداد پیدا نشد.',404);
      const previous=old?JSON.parse(old.data):{};
      const row={revision:revision(previous,body.revision),signed:date(body.signed),delivery:date(body.delivery),actualDelivery:previous.actualDelivery||'',delayReason:previous.delayReason||'',accessories:text(body.accessories),payment:text(body.payment),complete:true};
      if(row.delivery<row.signed || (row.actualDelivery&&row.actualDelivery<row.signed)) fail('تاریخ تحویل قبل از قرارداد است.');
      if(!row.payment||!Array.isArray(body.devices)||!body.devices.length||body.devices.length>30) fail('دستگاه‌ها و نحوه پرداخت لازم است.');
      if(row.actualDelivery){
        row.delayReason=row.actualDelivery>row.delivery?text(body.delayReason??row.delayReason):'';
        if(row.actualDelivery>row.delivery&&!row.delayReason)fail('با موعد جدید، علت تأخیر تحویل را وارد کنید.');
      }
      row.finance=paymentPlan(body,row.signed);totals(row.finance);
      row.devices=body.devices.map(d=>{
        const tonnage=Number(d?.tonnage), technicalFeatures=text(d?.technicalFeatures);
        if(!Number.isFinite(tonnage)||tonnage<=0||!technicalFeatures) fail('تناژ و مشخصات فنی دستگاه را وارد کنید.');
        const build=d.build;const customization=text(d.customization);
        if(!['standard','custom'].includes(build)||(build==='custom'&&!customization))fail('نوع دستگاه و جزئیات سفارشی‌سازی را تکمیل کنید.');
        return {tonnage,technicalFeatures,build,customization:build==='custom'?customization:''};
      });
      let target=cid;
      if(cid) db.prepare('UPDATE contracts SET data=? WHERE id=?').run(JSON.stringify(row),cid);
      else target=Number(db.prepare('INSERT INTO contracts(buyer_id,sales_id,data) VALUES(?,?,?)').run(id,b.salesId,JSON.stringify(row)).lastInsertRowid);
      writeFile(u,b,'contracts',target,body.attachment);
      audit(u,'قرارداد',target,cid?'ویرایش قرارداد':'ثبت قرارداد',old&&JSON.parse(old.data),row);profileTasks(id);
      return {id:target};
    });
  }
  function listRecords(b,kind){
    const leadColumn=kind==='contracts'?',r.lead_id AS leadId':'';
    const rows=db.prepare(`SELECT r.id,r.data,f.id AS fileId,f.name AS filename${leadColumn}
      FROM ${kind} r LEFT JOIN record_files f ON f.kind=? AND f.record_id=r.id
      WHERE r.buyer_id=? ORDER BY r.id DESC`).all(kind,b.id);
    return rows.map(({id,data,fileId,filename,...link})=>{
      const record=JSON.parse(data);
      return {...record,...link,id,summary:totals(record.finance),file:fileId?{id:fileId,name:filename}:null};
    });
  }
  function writeFile(u,b,kind,target,file){
    if(!file)return;
    if(typeof file.data!=='string'||!text(file.name,150))fail('فایل معتبر انتخاب کنید.');
    const bytes=Buffer.from(file.data,'base64');
    if(!bytes.length||bytes.length>5*1024*1024||bytes.toString('base64')!==file.data)fail('حداکثر اندازه فایل ۵ مگابایت است.');
    const old=db.prepare('SELECT name FROM record_files WHERE kind=? AND record_id=?').get(kind,target);
    db.prepare('INSERT INTO record_files(buyer_id,kind,record_id,name,bytes) VALUES(?,?,?,?,?) ON CONFLICT(kind,record_id) DO UPDATE SET name=excluded.name,bytes=excluded.bytes').run(b.id,kind,target,text(file.name,150),bytes);
    audit(u,'پیوست',target,'ذخیره فایل',old?.name,file.name);
  }
  function download(u,fileId){
    const row=db.prepare('SELECT buyer_id FROM record_files WHERE id=?').get(fileId);
    if(!row)fail('فایل پیدا نشد.',404);
    allowed(u,buyer(row.buyer_id));
    return db.prepare('SELECT name,bytes FROM record_files WHERE id=?').get(fileId);
  }
  function delivery(u,id,cid,body){
    return transaction(()=>{
      allowed(u,buyer(id),true);
      const item=db.prepare('SELECT data FROM contracts WHERE id=? AND buyer_id=?').get(cid,id);
      if(!item)fail('قرارداد پیدا نشد.',404);
      const old=JSON.parse(item.data);
      if(!old.delivery)fail('ابتدا موعد تحویل قرارداد را ثبت کنید.');
      const actual=date(body.actualDelivery);
      if(actual<old.signed||actual>today())fail('تاریخ واقعی تحویل معتبر نیست.');
      const delayReason=actual>old.delivery?text(body.delayReason):'';
      if(actual>old.delivery&&!delayReason)fail('علت تأخیر تحویل لازم است.');
      const row={...old,revision:revision(old,body.revision),actualDelivery:actual,delayReason};
      db.prepare('UPDATE contracts SET data=? WHERE id=?').run(JSON.stringify(row),cid);
      audit(u,'قرارداد',cid,'ثبت تحویل',old,row);return {id:cid};
    });
  }
  function writeService(u,id,sid,body){
    return transaction(()=>{
      const b=buyer(id);allowed(u,b,true);
      const prior=sid?db.prepare('SELECT data FROM services WHERE id=? AND buyer_id=?').get(sid,id):null;
      if(sid&&!prior)fail('خدمت پیدا نشد.',404);
      const old=prior&&JSON.parse(prior.data);
      const row={revision:revision(old,body.revision),type:text(body.type,150),part:text(body.part),description:text(body.description),warranty:text(body.warranty),requested:body.requested?date(body.requested):'',finished:body.finished?date(body.finished):'',created:old?.created||today()};
      if(!row.type)fail('نوع خدمت را وارد کنید.');
      if(row.requested&&row.finished&&row.finished<row.requested)fail('تاریخ اتمام قبل از درخواست است.');
      if(!['','دارد','ندارد'].includes(row.warranty))fail('وضعیت گارانتی معتبر نیست.');
      row.finance=paymentPlan(body,row.requested||row.created,true);totals(row.finance);
      let target=sid;
      if(sid)db.prepare('UPDATE services SET data=? WHERE id=?').run(JSON.stringify(row),sid);
      else target=Number(db.prepare('INSERT INTO services(buyer_id,data) VALUES(?,?)').run(id,JSON.stringify(row)).lastInsertRowid);
      writeFile(u,b,'services',target,body.attachment);audit(u,'خدمت',target,sid?'ویرایش خدمت':'ثبت خدمت',old,row);return {id:target};
    });
  }

  function repeat(u,id) {
    return transaction(()=>{
      const b=buyer(id);allowed(u,b,true);
      const active=db.prepare("SELECT id FROM customers WHERE json_extract(data,'$.buyerId')=? AND json_extract(data,'$.stage') NOT IN ('won','lost')").get(id);
      if(active)fail('درخواست خرید باز برای این مشتری وجود دارد.',409);
      const result=createLead(u,{...b,registrationNotes:'درخواست خرید مجدد'},id);
      audit(u,'مشتری',id,'درخواست خرید مجدد',null,result.customer.code);return result;
    });
  }
  function removeLead(u,id) {
    if(u.role!=='manager')fail('حذف متقاضی فقط با مدیر فروش است.',403);
    return transaction(()=>{
      const c=customer(id);
      db.prepare('DELETE FROM tasks WHERE customer_id=?').run(id);
      db.prepare('DELETE FROM events WHERE customer_id=?').run(id);
      db.prepare('DELETE FROM customers WHERE id=?').run(id);
      audit(u,'متقاضی',id,'حذف کامل پرونده',c.code,null);return {ok:true};
    });
  }
  return {saveBuyer,download,delivery,writeService,audit,buyerList,writeBuyer,writeContract,convert,repeat,removeLead};
}
