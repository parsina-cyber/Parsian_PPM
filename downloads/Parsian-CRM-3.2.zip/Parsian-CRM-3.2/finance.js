import {date,fail,text,today} from './domain.js';

import {fundSchedule} from './public/fund.js';

export const methods=['نقد','چکی','صندوق'];
function amount(v,label,optional=false){
  if(optional&&(v==null||v===''))return 0;
  if(!['string','number'].includes(typeof v)||!/^\d+$/.test(String(v))||!Number.isSafeInteger(Number(v)))fail(label+' را به تومان و به صورت عدد صحیح وارد کنید.');
  return Number(v);
}
function checkEntry(c){
  const value=amount(c.amount,'مبلغ چک'),issued=date(c.issued),due=date(c.due);
  if(!value||due<issued)fail('مبلغ و تاریخ‌های چک را بررسی کنید.');
  const status=c.status||'pending';
  if(!['pending','cleared','unpaid'].includes(status))fail('وضعیت چک نامعتبر است.');
  const cleared=c.cleared?date(c.cleared):'';
  if(cleared&&(status!=='cleared'||cleared<issued||cleared>today()))fail('تاریخ پاس شدن و وضعیت چک سازگار نیستند.');
  return {amount:value,issued,due,status,cleared,sayad:text(c.sayad,32),serial:text(c.serial,64),holder:text(c.holder,150),national:text(c.national,20)};
}
export function paymentPlan(b,base,optional=false){
  if(optional&&!b.payment)return null;
  if(!methods.includes(b.payment))fail('نحوه پرداخت را انتخاب کنید.');
  const total=amount(b.total,'مبلغ کل');
  const rate=Number(b.rate);
  if(b.rate==null||b.rate===''||!Number.isFinite(rate)||rate<0||rate>10000)fail('نرخ بهره سالانه را وارد کنید (برای بدون بهره، صفر).');
  const plan={payment:b.payment,total,rate,initialCost:amount(b.initialCost,'هزینه اولیه',true),base:date(base)};
  if(b.payment==='چکی'){
    const advance=amount(b.advance,'پیش‌پرداخت',true);
    if(!Array.isArray(b.checks)||!b.checks.length||b.checks.length>100)fail('بین یک تا ۱۰۰ چک ثبت کنید.');
    const checks=b.checks.map(checkEntry);
    const advanceDate=advance?date(b.advanceDate):'';
    if(advanceDate>today())fail('تاریخ دریافت پیش‌پرداخت نمی‌تواند در آینده باشد.');
    if(advance+checks.reduce((n,c)=>n+c.amount,0)!==total)fail('مجموع پیش‌پرداخت و چک‌ها باید برابر مبلغ کل باشد.');
    Object.assign(plan,{advance,advanceDate,checks});
  }else if(b.payment==='صندوق'){
    const schedule=fundSchedule(total,plan.base);
    if(b.fundAdvanceStatus==='received'&&!b.advanceDate)fail('تاریخ دریافت پیش‌پرداخت صندوق لازم است.');
    if(b.fundAdvanceStatus==='pending'&&b.advanceDate)fail('وضعیت و تاریخ دریافت پیش‌پرداخت صندوق سازگار نیستند.');
    const advanceDate=b.advanceDate?date(b.advanceDate):'';
    const balanceDate=b.balanceDate?date(b.balanceDate):'';
    if(advanceDate>today()||balanceDate>today())fail('تاریخ دریافت نمی‌تواند در آینده باشد.');
    if(balanceDate&&(!advanceDate||balanceDate<advanceDate))fail('تاریخ دریافت مانده باید پس از پیش‌پرداخت یا در همان روز باشد.');
    Object.assign(plan,schedule,{advanceDate,balanceDate});
  }else{
    const collected=amount(b.collected,'مبلغ دریافتی',true);
    if(collected>total)fail('مبلغ دریافت‌شده بیشتر از مبلغ کل است.');
    Object.assign(plan,{collected,due:date(b.due||base)});
  }
  return plan;
}
export function totals(plan){
  if(!plan)return null;
  const checks=plan.checks||[];
  let flows,received;
  if(plan.payment==='چکی'){
    flows=[{amount:plan.advance,day:plan.advanceDate||plan.base},...checks.map(c=>({amount:c.amount,day:c.due}))];
    received=plan.advance+checks.filter(c=>c.status==='cleared').reduce((sum,c)=>sum+c.amount,0);
  }else if(plan.payment==='صندوق'){
    flows=[{amount:plan.advance,day:plan.advanceDate||plan.base},{amount:plan.balance,day:plan.due}];
    received=(plan.advanceDate?plan.advance:0)+(plan.balanceDate?plan.balance:0);
  }else{
    flows=[{amount:plan.total,day:plan.due}];received=plan.collected;
  }
  const discounted=flows.reduce((sum,f)=>sum+f.amount/(1+plan.rate/100)**((Date.parse(f.day)-Date.parse(plan.base))/86400000/365),0);
  const present=Math.round(discounted-(plan.initialCost||0));
  if(!Number.isSafeInteger(present))fail('ارزش فعلی خارج از محدودهٔ محاسبه است.');
  return {total:plan.total,received,outstanding:plan.total-received,present};
}
export function installFinance(db){
  db.exec(`CREATE TABLE buyers_next(id INTEGER PRIMARY KEY,sales_id INTEGER REFERENCES users(id),data TEXT NOT NULL);
    INSERT INTO buyers_next SELECT * FROM buyers;
    UPDATE buyers_next SET data=json_set(data,'$.legacy',json('true'))
      WHERE NOT EXISTS(SELECT 1 FROM contracts WHERE buyer_id=buyers_next.id AND lead_id IS NOT NULL);
    CREATE TABLE contracts_next(id INTEGER PRIMARY KEY,buyer_id INTEGER NOT NULL REFERENCES buyers_next(id),lead_id INTEGER UNIQUE REFERENCES customers(id) ON DELETE SET NULL,sales_id INTEGER REFERENCES users(id),data TEXT NOT NULL);
    INSERT INTO contracts_next SELECT * FROM contracts;
    DROP TABLE contracts; DROP TABLE buyers;
    ALTER TABLE buyers_next RENAME TO buyers; ALTER TABLE contracts_next RENAME TO contracts;
    CREATE TABLE services(id INTEGER PRIMARY KEY,buyer_id INTEGER NOT NULL REFERENCES buyers(id),data TEXT NOT NULL);
    CREATE TABLE record_files(id INTEGER PRIMARY KEY,buyer_id INTEGER NOT NULL REFERENCES buyers(id),kind TEXT NOT NULL,record_id INTEGER NOT NULL,name TEXT NOT NULL,bytes BLOB NOT NULL,UNIQUE(kind,record_id));
    PRAGMA user_version=4;`);
}
