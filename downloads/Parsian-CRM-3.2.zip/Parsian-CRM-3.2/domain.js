import {installFinance} from './finance.js';
import {weeklyTracker} from './weekly.js';
import { records, SOURCES, TONNAGES, validateSource } from './records.js';
export const ROLES = ['secretary', 'sales', 'manager', 'technical', 'director'];
export const INTRO_TITLE = 'ارسال کاتالوگ و فیلم معرفی کارخانه';
export const today = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Tehran' }).format(new Date());
export const now = () => new Date().toISOString();
export const text = (v, max = 2000) => typeof v === 'string' ? v.trim().slice(0, max) : '';
export function fail(message, status = 400) { const e = new Error(message); e.status = status; throw e; }
export function date(v) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(v || '') || !Number.isFinite(Date.parse(v)) || new Date(v).toISOString().slice(0, 10) !== v) fail('تاریخ معتبر وارد کنید.');
  return v;
}
const plus = (day, n) => { const d = new Date(day + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const phone = value => text(value).replace(/[۰-۹٠-٩]/g, n => '۰۱۲۳۴۵۶۷۸۹'.includes(n) ? '۰۱۲۳۴۵۶۷۸۹'.indexOf(n) : '٠١٢٣٤٥٦٧٨٩'.indexOf(n)).replace(/[\s()-]/g, '');

export function createWorkflow(db) {
  let weekly;
  function transaction(fn) { db.exec('BEGIN IMMEDIATE'); try { weekly?.capture(); const r = fn(); db.exec('COMMIT'); return r; } catch (e) { db.exec('ROLLBACK'); throw e; } }
  const users = () => db.prepare('SELECT id,name,username,role,active FROM users ORDER BY id').all();
  function customer(id) {
    const row = db.prepare('SELECT * FROM customers WHERE id=?').get(id);
    if (!row) fail('متقاضی خرید پیدا نشد.', 404);
    return { ...JSON.parse(row.data), id: row.id, code: `P-${String(row.id).padStart(5, '0')}`, created: row.created, updated: row.updated };
  }
  function save(c) {
    const { id, code, created, updated, ...data } = c;
    db.prepare('UPDATE customers SET data=?,updated=? WHERE id=?').run(JSON.stringify(data), now(), id);
  }
  function event(id, uid, type, note = '') { db.prepare('INSERT INTO events(customer_id,user_id,type,note,created) VALUES(?,?,?,?,?)').run(id, uid, type, text(note, 10000), now()); }
  const activeTask = (id, kind) => db.prepare("SELECT * FROM tasks WHERE customer_id=? AND kind=? AND state IN ('open','paused') ORDER BY due,id LIMIT 1").get(id, kind);
  function task(id, owner, kind, title, due, round = 0) {
    date(due);
    // All automatic returns reuse an existing sales follow-up, including a paused one.
    if (kind === 'followup') { const existing = activeTask(id, kind); if (existing) return existing.id; }
    return Number(db.prepare('INSERT INTO tasks(customer_id,owner_id,kind,title,due,round,created) VALUES(?,?,?,?,?,?,?)').run(id, owner, kind, title, due, round, now()).lastInsertRowid);
  }
  function ensureSalesWork(c, due = today()) {
    const current = db.prepare("SELECT id FROM tasks WHERE customer_id=? AND kind IN ('discovery','followup','visit','contract') AND state IN ('open','paused') LIMIT 1").get(c.id);
    if (!current) task(c.id, c.salesId, 'followup', c.followupCount >= 4 ? 'پیگیری بلندمدت' : `تماس پیگیری ${c.followupCount + 1} از ۴`, due, c.followupCount + 1);
  }
  function canAccess(u, c) {
    if (['manager','director'].includes(u.role)) return true;
    if (u.role === 'sales') return c.salesId === u.id;
    if (u.role === 'technical') return c.stage === 'technical' && Boolean(db.prepare("SELECT id FROM tasks WHERE customer_id=? AND owner_id=? AND kind='technical' AND state='open'").get(c.id, u.id));
    return false;
  }
  function access(u, c) { if (!canAccess(u, c)) fail('به این پرونده دسترسی ندارید.', 403); }
  function salesAccess(u, c) { if (!(u.role === 'manager' || u.role === 'sales' && u.id === c.salesId)) fail('این اقدام با کارشناس فروش مسئول یا مدیر فروش است.', 403); }
  function publicCustomer(u, c) {
    if (u.role !== 'technical') return c;
    const { id, code, name, phone, messengerNumber, messengerType, address, position, industry, product, salesId, technicalId, stage, technicalRequest } = c;
    return { company:c.company, id, code, name, phone, messengerNumber, messengerType, address, position, industry, product, salesId, technicalId, stage, technicalRequest,
      devices: (c.devices || []).map(({ name, tonnage, technicalFeatures }) => ({ name, tonnage, technicalFeatures })) };
  }
  function dataFor(u) {
    const customers = db.prepare('SELECT id FROM customers ORDER BY id DESC').all().map(r => customer(r.id)).filter(c => canAccess(u, c));
    const ids = new Set(customers.map(c => c.id));
    const tasks = db.prepare('SELECT * FROM tasks ORDER BY due,id').all().filter(t => ids.has(t.customer_id) && (u.role !== 'technical' || t.kind === 'technical' && t.owner_id === u.id && t.state === 'open'));
    const directory = users().filter(member => u.role === 'secretary' ? member.role === 'sales' && member.active : u.role === 'technical' ? member.id === u.id || customers.some(c => c.salesId === member.id) : true);
    return { user: u, users: directory, customers: customers.map(c => publicCustomer(u, c)), tasks, buyers:store.buyerList(u), tonnages:TONNAGES, sources:SOURCES, today: today() };
  }
  function registration(b, old = {}, buyerId) {
    const c = { ...old, name: text(b.name ?? old.name, 150), phone: phone(b.phone ?? old.phone), registrationNotes: text(b.registrationNotes ?? old.registrationNotes, 10000) };
    if (!c.name || !/^\+?\d{7,15}$/.test(c.phone)) fail('نام و شماره تماس معتبر الزامی است.');
    if (old.id) {
      if (b.salesId !== undefined && Number(b.salesId) !== old.salesId) fail('کارشناس فروش متقاضی خرید پس از ثبت قابل تغییر نیست.', 409);
    } else {
      c.salesId = Number(b.salesId);
      if (!users().some(u => u.id === c.salesId && u.role === 'sales' && u.active)) fail('یک کارشناس فروش انتخاب کنید.');
    }
    if (c.phone !== old.phone) {
      const duplicate = db.prepare('SELECT data FROM customers WHERE id<>?').all(old.id||0).some(r=>{
        const other=JSON.parse(r.data);
        return phone(other.phone)===c.phone && !(buyerId && other.buyerId===buyerId);
      });
      if(duplicate) fail('این شماره تماس قبلاً ثبت شده است.',409);
    }
    return c;
  }
  function createCustomer(u, b) {
    if (!['secretary','sales','manager'].includes(u.role)) fail('اجازه ثبت متقاضی خرید ندارید.', 403);
    return transaction(() => createLead(u,b));
  }
  function createLead(u,b,buyerId) {
      const c = { ...registration(b,{},buyerId), ...(buyerId?{buyerId,company:b.company,position:b.position,source:b.source,referrer:b.referrer,address:b.address,industry:b.industry,product:b.product}:{}), firstContact: today(), stage: 'new', followupCount: 0, readiness: 'cold', technicalId: null, devices: [] };
      const id = Number(db.prepare('INSERT INTO customers(data,created,updated) VALUES(?,?,?)').run(JSON.stringify(c), now(), now()).lastInsertRowid);
      event(id, u.id, 'ثبت متقاضی خرید', `پرونده ایجاد شد؛ مسئول فروش: ${users().find(member => member.id === c.salesId).name}\n${c.registrationNotes}`);
      task(id, c.salesId, 'discovery', 'تماس اولیه و نیازسنجی', c.firstContact);
      const created = customer(id);
      return { customer: canAccess(u, created) ? created : { id, code: created.code, name: created.name, salesId: created.salesId } };
  }
  function importRows(u,kind,rows){
    if(!['sales','manager'].includes(u.role))fail('اجازه ورود گروهی ندارید.',403);
    if(!Array.isArray(rows)||!rows.length||rows.length>1000)fail('هر فایل باید بین ۱ تا ۱۰۰۰ ردیف داشته باشد.');
    const directory=users().filter(m=>m.active);
    function member(value,role){
      if(!value)return null;
      const found=directory.filter(m=>m.role===role&&(m.name===value||m.username===value));
      if(found.length!==1)fail('نام کارشناس نامعتبر یا مشترک است: '+text(value,100));
      return found[0].id;
    }
    return transaction(()=>{
      let added=0,skipped=0;
      for(const [i,row] of rows.entries()){
        try{
          if(!row||typeof row!=='object'||Array.isArray(row))fail('ردیف معتبر نیست.');
          const salesId=member(row.salesId,'sales')||(u.role==='sales'?u.id:null);
          if(u.role==='sales'&&salesId!==u.id)fail('ورود فقط برای پرونده‌های خودتان مجاز است.',403);
          if(kind==='buyers'){
            const duplicate=db.prepare("SELECT id FROM buyers WHERE json_extract(data,'$.name')=? AND coalesce(json_extract(data,'$.phone'),'')=? AND coalesce(json_extract(data,'$.company'),'')=? AND coalesce(json_extract(data,'$.address'),'')=?").get(text(row.name),phone(row.phone),text(row.company),text(row.address));
            if(duplicate){skipped++;continue;}
            store.saveBuyer(u,null,{...row,phone:phone(row.phone),salesId});added++;continue;
          }
          if(db.prepare("SELECT id FROM customers WHERE json_extract(data,'$.phone')=?").get(phone(row.phone))){skipped++;continue;}
          const created=createLead(u,{...row,salesId}).customer,c=customer(created.id);
          for(const key of ['company','referrer','messengerNumber','messengerType','address','position','industry','product','tonnage','source','discoveryNotes'])c[key]=text(row[key]);
          if(c.source)validateSource(c);
          c.firstContact=row.firstContact?date(row.firstContact):today();c.purchaseDate=row.purchaseDate?date(row.purchaseDate):'';
          c.readiness=row.readiness||'cold';if(!['cold','warm','hot'].includes(c.readiness))fail('آمادگی خرید معتبر نیست.');
          c.stage=row.stage||'new';if(!['new','discovery','technical','followup','longterm','visit','quote','contract','won','lost'].includes(c.stage))fail('مرحله فروش معتبر نیست.');
          c.technicalId=member(row.technicalId,'technical');
          if(row.devices){
            const devices=JSON.parse(row.devices);
            if(!Array.isArray(devices)||devices.length>30)fail('فهرست دستگاه‌ها معتبر نیست.');
            c.devices=devices.map(d=>({name:text(d.name),tonnage:text(String(d.tonnage??'')),technicalFeatures:text(d.technicalFeatures),quotedPrice:typeof d.quotedPrice==='number'?d.quotedPrice:text(d.quotedPrice)}));
          }
          c.followupCount=Number(row.followupCount||0);
          if(!Number.isSafeInteger(c.followupCount)||c.followupCount<0)fail('تعداد تماس پیگیری معتبر نیست.');
          if(c.stage==='longterm')c.followupCount=Math.max(4,c.followupCount);
          const due=row.nextDate?date(row.nextDate):today();
          db.prepare("DELETE FROM tasks WHERE customer_id=?").run(c.id);
          if(c.stage==='won')store.convert(c,row.signed?date(row.signed):'');
          else if(c.stage==='technical'){
            if(!c.technicalId)fail('مرحله فنی نیاز به کارشناس فنی دارد.');
            task(c.id,c.technicalId,'technical','مشاوره تخصصی فنی',due);
          }else if(c.stage!=='lost'){
            const kind=({new:'discovery',discovery:'discovery',visit:'visit',contract:'contract'})[c.stage]||'followup';
            const title=({discovery:'تماس اولیه و نیازسنجی',visit:'بازدید کارخانه',contract:'جلسه عقد قرارداد',followup:c.followupCount>=4?'پیگیری بلندمدت':`تماس پیگیری ${c.followupCount+1} از ۴`})[kind];
            task(c.id,c.salesId,kind,title,due,kind==='followup'?c.followupCount+1:0);
          }
          save(c);event(c.id,u.id,'ورود گروهی','ورود اطلاعات متقاضی از فایل');added++;
        }catch(e){fail('ردیف '+(Number.isSafeInteger(row?.line)?row.line:i+2)+': '+(e instanceof SyntaxError?'فرمت دستگاه‌ها معتبر نیست.':e.message),e.status||400);}
      }
      store.audit(u,'ورود گروهی',0,kind==='buyers'?'ورود مشتریان':'ورود متقاضیان',null,{added,skipped});
      return {added,skipped};
    });
  }

  function editCustomer(u, id, b) {
    return transaction(() => { const c = customer(id); salesAccess(u, c); const next = registration(b, c); save(next); store.audit(u,'متقاضی',id,'ویرایش ثبت اولیه',c,next); event(id, u.id, 'ویرایش اطلاعات', 'اطلاعات ثبت اولیه به‌روز شد؛ مسئول فروش ثابت ماند.'); return { customer: customer(id) }; });
  }
  function discovery(c, b) {
    for (const key of ['messengerNumber','messengerType','company','address','position','industry','product','source','referrer','readiness']) if (b[key] !== undefined) c[key] = text(b[key]);
    validateSource(c);
    if(!c.industry || !c.product || !['cold','warm','hot'].includes(c.readiness)) fail('اطلاعات نیازسنجی را کامل کنید.');
    if (!Array.isArray(b.devices) || !b.devices.length || b.devices.length > 30) fail('بین یک تا ۳۰ دستگاه ثبت کنید.');
    c.devices = b.devices.map(d => {
      const tonnage=Number(d?.tonnage), price=d?.quotedPrice;
      if (!TONNAGES.includes(tonnage)) fail('تناژ دستگاه معتبر نیست.');
      if (price!=null && price!=='' && (!['number','string'].includes(typeof price)||!/^\d+(?:\.\d+)?$/.test(String(price))||!Number.isFinite(Number(price)))) fail('قیمت را به عدد و به میلیون تومان وارد کنید.');
      return {tonnage,technicalFeatures:text(d.technicalFeatures),quotedPrice:price==null||price===''?null:Number(price)};
    });
    c.discoveryNotes = text(b.note, 10000);
  }
  function perform(u, id, b) {
    return transaction(() => {
      const c = customer(id); access(u, c);
      if (b.type==='editStage') return editStage(u,c,b);
      const previous=structuredClone(c);
      const type = b.type, note = text(b.note, 10000);
      const t = b.taskId ? db.prepare("SELECT * FROM tasks WHERE id=? AND customer_id=? AND state='open'").get(Number(b.taskId), id) : null;
      if (b.taskId && !t) fail('این کار قبلاً انجام شده یا باز نیست.', 409);
      if (u.role === 'technical') {
        if (type !== 'complete' || t?.kind !== 'technical' || t.owner_id !== u.id) fail('فقط اجازه پاسخ‌دادن به تیکت فنی تخصیص‌یافته را دارید.', 403);
      } else salesAccess(u, c);
      if (t && t.owner_id !== u.id && u.role !== 'manager') fail('این کار به شما تخصیص نیافته است.', 403);
      if(type==='reschedule' && u.role==='manager'){
        if(!t||!note)fail('کار و علت تغییر موعد لازم است.');
        const due=date(b.nextDate);
        store.audit(u,'موعد',t.id,'ویرایش تاریخ',t.due,due);
        db.prepare('UPDATE tasks SET due=? WHERE id=?').run(due,t.id);
        event(id,u.id,'تغییر موعد',t.title+' ← '+due+'\n'+note);
        return {customer:publicCustomer(u,c)};
      }
      if (['won','lost'].includes(c.stage) && !['note','reopen'].includes(type)) fail('پرونده بسته است؛ ابتدا آن را بازگشایی کنید.');
      if (c.stage === 'technical' && u.role !== 'technical' && !(type === 'complete' && t?.kind === 'technical') && !['note','close'].includes(type)) fail('پرونده در انتظار پاسخ فنی است.');
      const due = () => date(b.nextDate);
      const scheduledDate = () => date(b.scheduledDate);
      if(t?.kind==='profile')fail('اطلاعات را در پرونده مشتری تکمیل کنید.');
      if (type === 'note') { if (!note) fail('توضیحات را وارد کنید.'); event(id, u.id, 'یادداشت', note); }
      else if (type === 'reschedule') {
        if (!t || !note) fail('کار و علت تغییر موعد لازم است.');
        store.audit(u,'موعد',t.id,'ویرایش تاریخ',t.due,due()); db.prepare('UPDATE tasks SET due=? WHERE id=?').run(due(), t.id); event(id, u.id, 'تغییر موعد', `${t.title} ← ${b.nextDate}\n${note}`);
      } else if (type === 'technical') {
        if (activeTask(id, 'technical')) fail('یک درخواست فنی باز وجود دارد.');
        const techId = Number(b.technicalId);
        if (!users().some(member => member.id === techId && member.role === 'technical' && member.active)) fail('کارشناس فنی را انتخاب کنید.');
        if (!note) fail('موضوع مشاوره را بنویسید.');
        c.technicalId = techId; c.technicalRequest = note; c.technicalReturnStage = c.stage; c.stage = 'technical';
        db.prepare("UPDATE tasks SET state='paused' WHERE customer_id=? AND state='open' AND kind!='technical'").run(id);
        task(id, techId, 'technical', 'مشاوره تخصصی فنی', today()); event(id, u.id, 'درخواست مشاوره فنی', note);
      } else if (type === 'close') {
        if (!note || !['won','lost'].includes(b.outcome)) fail('نتیجه و علت بستن پرونده لازم است.');
        c.stage = b.outcome; c.closeReason = note;
        db.prepare("UPDATE tasks SET state='cancelled' WHERE customer_id=? AND state IN ('open','paused')").run(id);
        if(b.outcome==='won')store.convert(c,b.signed?date(b.signed):today());
        event(id, u.id, b.outcome === 'won' ? 'قرارداد منعقد شد' : 'عدم خرید و بستن پرونده', note);
      } else if (type === 'reopen') {
        if (!['won','lost'].includes(c.stage)) fail('پرونده بسته نیست.'); if (!note) fail('علت بازگشایی را وارد کنید.');
        c.stage = 'longterm'; task(id, c.salesId, 'followup', 'پیگیری بلندمدت', due(), c.followupCount + 1); event(id, u.id, 'بازگشایی پرونده', note);
      } else if (['visit','contract'].includes(type)) {
        if (activeTask(id, type)) fail('یک جلسه باز از این نوع وجود دارد.'); if (!note) fail('توضیحات جلسه را وارد کنید.');
        const day = scheduledDate(); if (b.time && !/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(b.time)) fail('ساعت جلسه معتبر نیست.');
        db.prepare("UPDATE tasks SET state='cancelled' WHERE customer_id=? AND kind='followup' AND state IN ('open','paused')").run(id);
        task(id, c.salesId, type, type === 'visit' ? 'بازدید کارخانه' : 'جلسه عقد قرارداد', day); c.stage = type;
        event(id, u.id, type === 'visit' ? 'برنامه‌ریزی بازدید' : 'برنامه‌ریزی قرارداد', `${day}${b.time ? ' — ' + b.time : ''}\n${note}`);
      } else if (type === 'quote') {
        const labels = { pending:'نیازمند تهیه', ready:'آماده ارسال', sent:'ارسال‌شده', unneeded:'فعلاً لازم نیست' };
        if (!Object.hasOwn(labels, b.quoteStatus) || !note) fail('وضعیت و جزئیات پیش‌فاکتور را وارد کنید.');
        c.quoteStatus = b.quoteStatus; c.quoteNumber = text(b.quoteNumber, 100); c.quoteDate = b.quoteStatus === 'sent' ? date(b.sentDate || today()) : ''; c.stage = 'quote';
        const sent=c.quoteStatus==='sent'; c.quoteCount=(c.quoteCount||0)+(sent?1:0);
        event(id, u.id, 'به‌روزرسانی پیش‌فاکتور', `${labels[c.quoteStatus]} ${c.quoteNumber}\n${note}`); ensureSalesWork(c);
      } else if (type === 'complete') {
        if (!t) fail('کار را انتخاب کنید.');
        if (!note && !['introduction','trust'].includes(t.kind)) fail('توضیحات و نتیجه را وارد کنید.');
        if(t.kind==='discovery' && !b.nextDate)b.nextDate=plus(b.actualDate||today(),7);
        const actual = date(b.actualDate || today()); if (actual > today()) fail('تاریخ انجام نمی‌تواند در آینده باشد.');
        if (['discovery','followup'].includes(t.kind)) {
          if (!['success','noanswer','later','invalid'].includes(b.result)) fail('نتیجه تماس را مشخص کنید.');
          if(t.kind==='followup'&&!['hot','cold','warm'].includes(b.readiness)) fail('آمادگی خرید این تماس را ثبت کنید.');
          const next = due(); if (next < actual) fail('موعد بعدی نمی‌تواند قبل از تماس باشد.');
          if (b.result !== 'success') {
            db.prepare('UPDATE tasks SET due=? WHERE id=?').run(next, t.id);
            event(id, u.id, 'تلاش تماس', `${t.title} — ${{ noanswer:'پاسخ نداد', later:'درخواست تماس در زمان دیگر', invalid:'شماره نامعتبر' }[b.result]} — ${actual}\n${note}`);
            recordStage(u,c,b,t); save(c); return { customer: publicCustomer(u, customer(id)) };
          }
        }
        // Complete before scheduling the successor, so the unique follow-up rule also covers retries.
        db.prepare("UPDATE tasks SET state='done' WHERE id=?").run(t.id);
        if (t.kind === 'discovery') {
          discovery(c, b); c.stage = 'followup';
          task(id, c.salesId, 'introduction', INTRO_TITLE, actual);
          task(id, c.salesId, 'trust', 'ارسال محتوای اعتمادسازی', plus(actual, 2));
          task(id, c.salesId, 'followup', 'تماس پیگیری ۱ از ۴', due(), 1);
        } else if (t.kind === 'followup') {
          c.followupCount += 1;
          if (b.readiness !== undefined) { if (!['cold','warm','hot'].includes(b.readiness)) fail('آمادگی خرید معتبر نیست.'); c.readiness = b.readiness; }
          if (b.purchaseDate) c.purchaseDate = date(b.purchaseDate);
          c.stage = c.followupCount >= 4 ? 'longterm' : 'followup';
          task(id, c.salesId, 'followup', c.followupCount >= 4 ? 'پیگیری بلندمدت' : `تماس پیگیری ${c.followupCount + 1} از ۴`, due(), c.followupCount + 1);
        } else if (t.kind === 'technical') {
          c.stage = c.technicalReturnStage || (c.followupCount >= 4 ? 'longterm' : 'followup'); delete c.technicalReturnStage;
          db.prepare("UPDATE tasks SET state='open' WHERE customer_id=? AND state='paused' AND kind!='technical'").run(id);
          ensureSalesWork(c, actual);
        } else if (['visit','contract'].includes(t.kind)) {
          if (b.meetingResult !== undefined && !['held','cancelled','noShow',...(t.kind==='contract'?['signed']:[])].includes(b.meetingResult)) fail('نتیجه جلسه معتبر نیست.');
          if (['cancelled','noShow'].includes(b.meetingResult)) db.prepare("UPDATE tasks SET state='cancelled' WHERE id=?").run(t.id);
          if (t.kind==='contract'&&b.meetingResult==='signed') {
            c.stage='won';c.closeReason=note;
            db.prepare("UPDATE tasks SET state='cancelled' WHERE customer_id=? AND state IN ('open','paused')").run(id);
            store.convert(c,actual);
          } else {c.stage = c.followupCount >= 4 ? 'longterm' : 'followup'; ensureSalesWork(c, actual);}
        }
        event(id, u.id, t.kind === 'technical' ? 'پاسخ مشاوره فنی و بازگشت به فروش' : t.title,
          `تاریخ انجام: ${actual}\n${b.meetingResult ? { held:'جلسه برگزار شد', signed:'قرارداد امضا شد', cancelled:'جلسه لغو شد', noShow:'مشتری حاضر نشد' }[b.meetingResult] + '\n' : ''}${note || 'ارسال انجام شد'}`);
      } else fail('اقدام معتبر نیست.');
      recordStage(u,c,b,t);
      if(type==='quote' && b.attachment) attach(c.id,b.attachment);
      if(['reopen','quote'].includes(type))store.audit(u,'متقاضی',id,type==='quote'?'پیش‌فاکتور':'بازگشایی',previous,c);
      save(c); return { customer: canAccess(u, c) ? publicCustomer(u, customer(id)) : null };
    });
  }

  const store=records(db,{customer,task,transaction,createLead});
  function recordStage(u,c,b,t) {
    const row=db.prepare('SELECT id FROM events WHERE customer_id=? ORDER BY id DESC LIMIT 1').get(c.id);
    const {attachment, ...raw}=b;
    const details=Object.fromEntries(Object.entries(raw).filter(([k])=>['type','note','actualDate','result','readiness','nextDate','scheduledDate','time','quoteStatus','quoteNumber','sentDate','meetingResult','outcome'].includes(k)));
    details.kind=b.type==='complete'?t.kind:b.type;
    if(t)details.taskId=t.id;
    if(b.type==='complete')details.actualDate=b.actualDate||today();
    if(b.type==='quote')details.sentDate=c.quoteDate;
    if(b.type==='complete'&&details.kind==='discovery'&&b.result==='success')details.discovery=true;
    if((b.type==='complete'&&t?.kind==='followup')||details.discovery) {
      c.readiness=b.readiness||c.readiness;
      details.readiness=c.readiness;
      c.readinessHistory??=[];
      c.readinessHistory.push({eventId:row.id,day:b.actualDate||today(),registered:today(),value:c.readiness});
    }
    if(b.type==='reschedule')details.nextTask=t.id;
    else if(b.nextDate)details.nextTask=activeTask(c.id,t?.kind==='discovery'&&b.result!=='success'?'discovery':'followup')?.id;
    if(['visit','contract'].includes(b.type))details.scheduledTask=activeTask(c.id,b.type)?.id;
    if(b.type==='quote'&&b.quoteStatus==='sent')details.sendNumber=c.quoteCount;
    db.prepare('UPDATE events SET details=? WHERE id=?').run(JSON.stringify(details),row.id);
  }
  function attach(id,a,existingId) {
    if(!a || typeof a.data!=='string'||typeof a.name!=='string')fail('فایل نامعتبر است.');
    const bytes=Buffer.from(a.data,'base64');
    if(!bytes.length||bytes.length>5*1024*1024||bytes.toString('base64')!==a.data)fail('فایل باید حداکثر ۵ مگابایت باشد.');
    const eventId=existingId||db.prepare('SELECT max(id) AS id FROM events WHERE customer_id=?').get(id).id;
    db.prepare('INSERT INTO attachments(event_id,name,bytes) VALUES(?,?,?) ON CONFLICT(event_id) DO UPDATE SET name=excluded.name, bytes=excluded.bytes').run(eventId,text(a.name,150),bytes);
  }
  function editStage(u,c,b) {
    salesAccess(u,c);
    const e=db.prepare('SELECT * FROM events WHERE id=? AND customer_id=?').get(Number(b.eventId),c.id);
    if(!e||e.user_id!==u.id||e.type.startsWith('ویرایش'))fail('فقط ثبت‌کننده می‌تواند این مرحله را ویرایش کند.',403);
    const d=JSON.parse(e.details||'{}'), before={...d,note:e.note};
    const note=text(b.note,10000);if(!note)fail('توضیحات را وارد کنید.');
    if(d.discovery) {
      const last=c.readiness;
      discovery(c,b);
      c.readiness=last;
    }
    if(d.actualDate&&b.actualDate){d.actualDate=date(b.actualDate);if(d.actualDate>today())fail('تاریخ انجام در آینده است.');}
    if(b.readiness && (d.readiness||d.discovery||d.kind==='followup')){
      if(!['cold','warm','hot'].includes(b.readiness))fail('آمادگی خرید معتبر نیست.');
      d.readiness=b.readiness;
      c.readinessHistory??=[];
      let point=c.readinessHistory.find(h=>h.eventId===e.id);
      if(!point){point={eventId:e.id,registered:today()};c.readinessHistory.push(point);c.readinessHistory.sort((a,b)=>a.eventId-b.eventId);}
      if(point){point.value=b.readiness;point.day=d.actualDate||point.day||today();c.readiness=c.readinessHistory.at(-1).value;}
    }
    if(d.nextTask&&b.nextDate && b.nextDate!==d.nextDate){d.nextDate=date(b.nextDate);if(d.actualDate&&d.nextDate<d.actualDate)fail('تاریخ پیگیری قبل از تماس است.');
      db.prepare("UPDATE tasks SET due=? WHERE id=? AND state IN ('open','paused')").run(d.nextDate,d.nextTask);}
    if(d.scheduledTask && b.time!==undefined){if(b.time&&!/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(b.time))fail('ساعت جلسه معتبر نیست.');d.time=b.time;}
    if(d.scheduledTask && b.scheduledDate){d.scheduledDate=date(b.scheduledDate);db.prepare('UPDATE tasks SET due=? WHERE id=?').run(d.scheduledDate,d.scheduledTask);}
    if(d.kind==='quote'){
      const status=b.quoteStatus??d.quoteStatus;
      if(!['pending','ready','sent','unneeded'].includes(status)) fail('وضعیت پیش‌فاکتور معتبر نیست.');
      d.quoteStatus=status;d.quoteNumber=text(b.quoteNumber??d.quoteNumber,100);
      d.sentDate=status==='sent'?date(b.sentDate||d.sentDate||today()):'';
    }
    if(['visit','contract'].includes(d.kind)&&d.meetingResult&&d.meetingResult!=='signed'&&b.meetingResult){
      if(!['held','cancelled','noShow'].includes(b.meetingResult))fail('نتیجه بازدید نامعتبر است.');
      d.meetingResult=b.meetingResult;
      if(d.taskId)db.prepare('UPDATE tasks SET state=? WHERE id=?').run(b.meetingResult==='held'?'done':'cancelled',d.taskId);
    }
    if(d.type==='technical' && c.stage==='technical' && !db.prepare("SELECT id FROM events WHERE customer_id=? AND id>? AND type='درخواست مشاوره فنی'").get(c.id,e.id))c.technicalRequest=note;
    if(d.type==='close' && c.stage===d.outcome && !db.prepare("SELECT id FROM events WHERE customer_id=? AND id>? AND json_extract(details,'$.type')='close'").get(c.id,e.id))c.closeReason=note;
    if(d.kind==='quote' && b.attachment){
      const oldFile=db.prepare('SELECT name,length(bytes) AS size FROM attachments WHERE event_id=?').get(e.id);
      attach(c.id,b.attachment,e.id);
      const newFile=db.prepare('SELECT name,length(bytes) AS size FROM attachments WHERE event_id=?').get(e.id);
      store.audit(u,'فایل پیش‌فاکتور',e.id,'جایگزینی فایل',oldFile,newFile);
    }
    d.note=note;
    const changes={details:d, prospect:c};
    store.audit(u,'مرحله',e.id,'ویرایش '+e.type,{details:before,prospect:customer(c.id)},changes);
    db.prepare('UPDATE events SET details=?,note=? WHERE id=?').run(JSON.stringify(d),note,e.id);
    if(d.kind==='quote')syncQuotes(c);
    event(c.id,u.id,'ویرایش مرحله',e.type);save(c);return {ok:true};
  }
  function syncQuotes(c) {
    let count=0;
    for(const e of db.prepare("SELECT id,details FROM events WHERE customer_id=? AND json_extract(details,'$.kind')='quote' ORDER BY id").all(c.id)){
      const q=JSON.parse(e.details);
      if(q.quoteStatus==='sent')q.sendNumber=++count;else delete q.sendNumber;
      db.prepare('UPDATE events SET details=? WHERE id=?').run(JSON.stringify(q),e.id);
      c.quoteStatus=q.quoteStatus;c.quoteNumber=q.quoteNumber;c.quoteDate=q.sentDate||'';
    }
    c.quoteCount=count;
  }
  // Upgrade legacy data once, retaining historical rows and the original salesperson IDs.
  transaction(() => {
    if (db.prepare('PRAGMA user_version').get().user_version < 2) {
      db.prepare("UPDATE users SET role='manager' WHERE role='admin'").run();
      for (const row of db.prepare('SELECT id FROM customers').all()) {
        const c = customer(row.id);
        c.registrationNotes ??= '';
        c.discoveryNotes ??= c.generalNotes || '';
        c.devices ??= c.tonnage ? [{ name:'دستگاه ثبت‌شده قبلی', tonnage:c.tonnage, technicalFeatures:c.technicalFeatures || '', quotedPrice:c.quotedPrice || '' }] : [];
        const media = db.prepare("SELECT * FROM tasks WHERE customer_id=? AND kind IN ('catalog','film') AND state IN ('open','paused') ORDER BY due,id").all(c.id);
        if (media.length) {
          db.prepare('UPDATE tasks SET kind=?,title=? WHERE id=?').run('introduction', INTRO_TITLE, media[0].id);
          for (const extra of media.slice(1)) db.prepare("UPDATE tasks SET state='cancelled' WHERE id=?").run(extra.id);
        }
        const followups = db.prepare("SELECT id FROM tasks WHERE customer_id=? AND kind='followup' AND state IN ('open','paused') ORDER BY due,id").all(c.id);
        for (const extra of followups.slice(1)) db.prepare("UPDATE tasks SET state='cancelled' WHERE id=?").run(extra.id);
        if (c.stage === 'technical') {
          c.technicalRequest ??= db.prepare("SELECT note FROM events WHERE customer_id=? AND type='درخواست مشاوره فنی' ORDER BY id DESC LIMIT 1").get(c.id)?.note || '';
          db.prepare("UPDATE tasks SET state='paused' WHERE customer_id=? AND kind!='technical' AND state='open'").run(c.id);
        }
        const { id, code, created, updated, ...stored } = c;
        db.prepare('UPDATE customers SET data=? WHERE id=?').run(JSON.stringify(stored), id);
      }
      db.exec('PRAGMA user_version=2');
    }
    if(db.prepare('PRAGMA user_version').get().user_version<3){
      db.exec(`ALTER TABLE users ADD COLUMN active INTEGER NOT NULL DEFAULT 1;
        ALTER TABLE events ADD COLUMN details TEXT;
        CREATE TABLE buyers(id INTEGER PRIMARY KEY,sales_id INTEGER NOT NULL REFERENCES users(id),data TEXT NOT NULL);
        CREATE TABLE contracts(id INTEGER PRIMARY KEY,buyer_id INTEGER NOT NULL REFERENCES buyers(id),lead_id INTEGER UNIQUE REFERENCES customers(id) ON DELETE SET NULL,sales_id INTEGER NOT NULL REFERENCES users(id),data TEXT NOT NULL);
        CREATE TABLE attachments(event_id INTEGER PRIMARY KEY REFERENCES events(id) ON DELETE CASCADE,name TEXT NOT NULL,bytes BLOB NOT NULL);
        CREATE TABLE audit(id INTEGER PRIMARY KEY,actor INTEGER,entity TEXT,target INTEGER,action TEXT,previous TEXT,value TEXT,created TEXT);
      `);
      for(const {id} of db.prepare('SELECT id FROM customers').all()){
        const c=customer(id);
        const discoveryEvent=db.prepare("SELECT * FROM events WHERE customer_id=? AND type='تماس اولیه و نیازسنجی' ORDER BY id LIMIT 1").get(id);
        if(discoveryEvent){
          const day=discoveryEvent.note.match(/تاریخ انجام: (\d{4}-\d{2}-\d{2})/)?.[1]||discoveryEvent.created.slice(0,10);
          db.prepare('UPDATE events SET details=? WHERE id=?').run(JSON.stringify({kind:'discovery',discovery:true,actualDate:day,note:c.discoveryNotes}),discoveryEvent.id);
        }
        const quoteLabels={pending:'نیازمند تهیه',ready:'آماده ارسال',sent:'ارسال‌شده',unneeded:'فعلاً لازم نیست'};
        // Old entries kept the meeting outcome, contact date and schedule in the Persian event text.
        // Only recover values actually recorded. Old readiness observations were never stored per call.
        for(const e of db.prepare('SELECT id,type,note FROM events WHERE customer_id=? AND details IS NULL ORDER BY id').all(id)){
          const done=e.note.match(/^تاریخ انجام: (\d{4}-\d{2}-\d{2})\n([\s\S]*)$/);
          if(done){
            const meeting={'جلسه برگزار شد':'held','جلسه لغو شد':'cancelled','مشتری حاضر نشد':'noShow'};
            const kind=e.type==='بازدید کارخانه'?'visit':e.type==='جلسه عقد قرارداد'?'contract':e.type.includes('پیگیری')?'followup':'complete';
            const [result,...rest]=done[2].split('\n');
            const hasMeeting=['visit','contract'].includes(kind) && Object.hasOwn(meeting,result);
            const d={type:'complete',kind,actualDate:done[1],note:hasMeeting?rest.join('\n'):done[2]};
            if(hasMeeting)d.meetingResult=meeting[result];
            db.prepare('UPDATE events SET details=? WHERE id=?').run(JSON.stringify(d),e.id);
          }
        }
        const oldQuotes=db.prepare("SELECT id,note,created FROM events WHERE customer_id=? AND type='به‌روزرسانی پیش‌فاکتور' ORDER BY id").all(id);
        for(const q of oldQuotes){
          const [heading,...notes]=q.note.split('\n');
          const entry=Object.entries(quoteLabels).find(([,label])=>heading.startsWith(label));
          if(!entry)continue;
          const [status,label]=entry;
          const last=q.id===oldQuotes.at(-1).id;
          const details={kind:'quote',type:'quote',quoteStatus:status,quoteNumber:heading.slice(label.length).trim(),note:notes.join('\n'),sentDate:status==='sent'&&last?c.quoteDate||'':''};
          db.prepare('UPDATE events SET details=? WHERE id=?').run(JSON.stringify(details),q.id);
        }
        syncQuotes(c);
        if(c.stage==='won'){
          const won=db.prepare("SELECT created FROM events WHERE customer_id=? AND type='قرارداد منعقد شد' ORDER BY id DESC LIMIT 1").get(id);
          store.convert(c,(won?.created||c.updated).slice(0,10));
        }
        const {id:leadId,created,updated,code,...stored}=c;
        db.prepare('UPDATE customers SET data=? WHERE id=?').run(JSON.stringify(stored),leadId);
      }
      db.exec('PRAGMA user_version=3');
    }
    if(db.prepare('PRAGMA user_version').get().user_version<4)installFinance(db);
    db.exec("CREATE UNIQUE INDEX IF NOT EXISTS one_active_followup ON tasks(customer_id) WHERE kind='followup' AND state IN ('open','paused')");
  });
  weekly=weeklyTracker(db);
  const updateWeeks=()=>transaction(()=>{});
  updateWeeks();
  return { importRows,updateWeeks,weeklyReports:weekly.reports,...store, users, customer, transaction, canAccess, access, publicCustomer, dataFor, createCustomer, editCustomer, perform };
}
