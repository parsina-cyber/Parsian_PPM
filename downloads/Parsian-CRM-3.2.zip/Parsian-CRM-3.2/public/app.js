import {fundSchedule} from './fund.js';
import {readSheet} from './sheets.js';
const $ = (s, el=document) => el.querySelector(s);
const $$ = (s, el=document) => [...el.querySelectorAll(s)];
const app = $('#app'), modal = $('#modal'), calendar = $('#calendar');
let state = { page:'dashboard', search:'', stage:'', readiness:'', owner:'', sort:'updated', taskFilter:'today', tasksMine:false, selected:null }, data, currentUser, needsSetup;
const fa = n => Number(n || 0).toLocaleString('fa-IR');
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const digits = s => String(s).replace(/[۰-۹٠-٩]/g, c => '۰۱۲۳۴۵۶۷۸۹'.includes(c) ? '۰۱۲۳۴۵۶۷۸۹'.indexOf(c) : '٠١٢٣٤٥٦٧٨٩'.indexOf(c));
const today = () => data?.today || new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Tehran'}).format(new Date());
const plus = (day,n) => { const d=new Date(day+'T12:00:00Z'); d.setUTCDate(d.getUTCDate()+n); return d.toISOString().slice(0,10); };
const persian = new Intl.DateTimeFormat('en-US-u-ca-persian',{year:'numeric',month:'numeric',day:'numeric',timeZone:'UTC'});
function parts(iso) { const p=Object.fromEntries(persian.formatToParts(new Date(iso+'T12:00:00Z')).map(x=>[x.type,x.value])); return {y:+p.year,m:+p.month,d:+p.day}; }
function jalali(iso) { if(!iso)return ''; const p=parts(iso.slice(0,10)); return `${p.y}/${String(p.m).padStart(2,'0')}/${String(p.d).padStart(2,'0')}`.replace(/\d/g,n=>'۰۱۲۳۴۵۶۷۸۹'[n]); }
function fromJalali(value) { const v=digits(value).trim(); if(!v)return ''; const match=/^(\d{4})[/-](\d{1,2})[/-](\d{1,2})$/.exec(v); if(!match)throw Error('تاریخ را به صورت شمسی، مانند ۱۴۰۵/۰۸/۱۳ وارد کنید.'); const [,ys,ms,ds]=match,y=+ys,m=+ms,d=+ds; if(y<1300 || y>1550 || m<1 || m>12 || d<1 || d>31)throw Error('تاریخ شمسی معتبر نیست.'); let base=`${y+621}-03-01`; for(let i=0;i<400;i++) { const iso=plus(base,i),p=parts(iso); if(p.y===y&&p.m===m&&p.d===d)return iso; } throw Error('این روز در تقویم شمسی وجود ندارد.'); }
const displayDate = iso => iso ? new Intl.DateTimeFormat('fa-IR-u-ca-persian',{day:'numeric',month:'long',timeZone:'Asia/Tehran'}).format(new Date(iso.slice(0,10)+'T12:00:00Z')) : 'تعیین نشده';
const stages={new:'ثبت اولیه',discovery:'نیازسنجی',technical:'مشاوره فنی',followup:'پیگیری فروش',longterm:'پیگیری بلندمدت',visit:'بازدید کارخانه',quote:'پیش‌فاکتور',contract:'جلسه قرارداد',won:'قرارداد موفق',lost:'عدم خرید'};
const readiness={cold:'سرد',warm:'ولرم',hot:'گرم'};
const roles={secretary:'کارشناس پذیرش',sales:'کارشناس فروش',manager:'مدیر فروش',technical:'کارشناس فنی',director:'مدیریت'};
const rolePages=()=>currentUser.role==='secretary'?['register']:currentUser.role==='technical'?['tasks']:['manager','director'].includes(currentUser.role)?['dashboard','customers','buyers','tasks','team','reports','finance']:['dashboard','customers','buyers','tasks'];
const canSell=()=>['sales','manager'].includes(currentUser.role);
const canRegister=()=>['secretary','sales','manager'].includes(currentUser.role);
const quoteLabels={pending:'نیازمند تهیه',ready:'آماده ارسال',sent:'ارسال‌شده',unneeded:'فعلاً لازم نیست'};
const paths={grid:'M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h7v7h-7z',users:'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2 M16 3a4 4 0 0 1 0 8 M22 21v-2a4 4 0 0 0-3-3.87 M9 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8',check:'m9 11 3 3 8-9 M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11',search:'M21 21l-4.35-4.35 M11 3a8 8 0 1 0 0 16 8 8 0 0 0 0-16',plus:'M12 5v14 M5 12h14',arrow:'M19 12H5 m6-6-6 6 6 6',bell:'M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9 M10 21h4',phone:'M22 16.9v3a2 2 0 0 1-2.2 2A19.8 19.8 0 0 1 3.1 5.2 2 2 0 0 1 5.1 3h3a2 2 0 0 1 2 1.7l.5 2.7a2 2 0 0 1-.6 1.8L8.7 10.5a16 16 0 0 0 4.8 4.8l1.3-1.3a2 2 0 0 1 1.8-.6l2.7.5a2 2 0 0 1 1.7 2z',clock:'M12 8v4l3 2 M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20',spark:'m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5z',close:'m6 6 12 12 M6 18 18 6',chevron:'m9 5 7 7-7 7',calendar:'M8 2v4 M16 2v4 M3 10h18 M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2',logout:'M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4 M16 17l5-5-5-5 M21 12H9',edit:'m16 3 5 5-13 13H3v-5z',file:'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z M14 2v6h6 M8 13h8 M8 17h5',shield:'M12 22s9-4 9-11V5l-9-3-9 3v6c0 7 9 11 9 11',download:'M12 3v12 m-5-5 5 5 5-5 M5 16v5h14v-5',filter:'M4 4h16l-6 7v7l-4 2v-9z',send:'m22 2-7 20-4-9L2 9z M22 2 11 13',briefcase:'M9 6V3h6v3 M3 7h18v14H3z M3 12h18 M10 12v3h4v-3'};
const icon=(name,cls='')=>`<svg class="icon ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${paths[name]||paths.file}"/></svg>`;
const contactName=c=>c?.company ? `${c.name} (${c.company})` : c?.name||'';
function priceLabel(n){
 if(n==null||n==='')return '';
 const value=Number(n);
 if(!Number.isFinite(value))return String(n);
 const amount=value>=1000?value/1000:value;
 return amount.toLocaleString('fa-IR',{maximumFractionDigits:9})+(value>=1000?' میلیارد تومان':' میلیون تومان');
}
function readinessPlot(history=[]){
 if(!history.length)return '<p>هنوز ثبت نشده</p>';
 return '<ol class="heat-history">'+[...history].sort((a,b)=>(a.registered||a.day).localeCompare(b.registered||b.day)||a.eventId-b.eventId).map(h=>
 `<li><span><time>${jalali(h.registered||h.day)}</time> · ${esc(readiness[h.value])}</span><meter class="heat-${esc(h.value)}" min="0" max="3" value="${({cold:1,warm:2,hot:3})[h.value]||0}" aria-label="${esc(readiness[h.value])}"></meter></li>`).join('')+'</ol>';
}
const userName=id=>data.users.find(u=>u.id===Number(id))?.name || '—';
const openTasks=()=>data.tasks.filter(t=>t.state==='open');
const badge=(value,type='stage')=>`<span class="badge ${esc(value)}">${type==='stage'?esc(stages[value]):esc(readiness[value])}</span>`;
async function api(path,method='GET',body) { const res=await fetch('/api/'+path,{method,headers:body?{'Content-Type':'application/json'}:{},body:body?JSON.stringify(body):undefined}); const value=await res.json(); if(!res.ok)throw Error(value.error || 'خطا در ارتباط با سرور'); return value; }
let toastTimer;
function toast(message,error=false){const el=$('#toast');el.textContent=message;el.className=error?'visible error':'visible';clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.className='',5000);}
async function load(){data=await api('data');currentUser=data.user;if(state.role!==currentUser.role){state.role=currentUser.role;state.page=rolePages()[0];state.taskFilter=currentUser.role==='technical'?'all':'today';}render();}
function dateInput(name,label,value='',required=false){return `<label>${label}<span class="date-wrap"><input type="text" name="${name}" class="jdate" value="${jalali(value)}" placeholder="۱۴۰۵/۰۸/۱۳" inputmode="numeric" autocomplete="off" ${required?'required':''}><button type="button" data-action="calendar" aria-label="انتخاب ${label}">${icon('calendar')}</button></span></label>`;}
function input(name,label,value='',type='text',required=false,passwordAutocomplete='new-password'){return `<label>${label}<input name="${name}" type="${type}" value="${esc(value)}" ${required?'required':''} ${['phone','messengerNumber','username'].includes(name)?'dir="ltr"':''} ${name==='password'?`minlength="8" maxlength="128" autocomplete="${passwordAutocomplete}"`:''}></label>`;}
function select(name,label,options,value='',required=false){return `<label>${label}<select name="${name}" ${required?'required':''}>${options.map(([v,t])=>`<option value="${esc(v)}" ${String(value)===String(v)?'selected':''}>${esc(t)}</option>`).join('')}</select></label>`;}
const note=(label='توضیحات',value='',name='note')=>`<label class="full">${label}<textarea name="${name}" rows="3" required>${esc(value)}</textarea></label>`;
function auth(){app.innerHTML=`<main class="auth-page"><div class="auth-art"><div class="wordmark"><img src="/mark.svg" alt="">پارسیان<span>CRM</span></div><span class="eyebrow">هر ارتباط، یک فرصت تازه</span><h1>رابطه‌های ماندگار،<br><em>فروش‌های موفق.</em></h1><p>از اولین تماس تا امضای قرارداد،<br>کنار متقاضی خرید بمانید.</p><div class="art-orbit"><span>ارتباط</span><span>اعتماد</span><span>رشد</span></div><small>فضای یکپارچه تیم فروش پارسیان</small></div><section class="auth-card"><span class="mini-label">خوش آمدید به پارسیان</span><h2>${needsSetup?'تیم شما از اینجا شروع می‌شود':'ورود به فضای کار'}</h2><p>${needsSetup?'حساب مدیر فروش را بسازید؛ سپس کارشناس پذیرش و کارشناسان فروش و فنی را اضافه کنید.':'برای دیدن متقاضیان خرید و پیگیری‌های خود وارد شوید.'}</p><form id="auth-form">${needsSetup?input('name','نام و نام خانوادگی','','text',true):''}${input('username','نام کاربری','','text',true)}${input('password','رمز عبور','','password',true,needsSetup?'new-password':'current-password')}<p class="form-error" role="alert"></p><button class="primary wide">${needsSetup?'ساخت حساب و شروع کار':'ورود به حساب'}${icon('arrow')}</button></form><div class="security-note">${icon('shield')} اطلاعات شما در پایگاه‌داده اختصاصی ذخیره می‌شود.</div></section></main>`;}
function render(){
 if(!rolePages().includes(state.page))state.page=rolePages()[0];
 const due=openTasks().filter(t=>t.due<=today()).length;
 const labels={dashboard:'نمای کلی',customers:'متقاضیان خرید',buyers:'مشتریان',finance:'داشبورد مالی',reports:'گزارش فروش',tasks:currentUser.role==='technical'?'تیکت‌های فنی':'پیگیری‌ها',team:'اعضای تیم',register:'ثبت متقاضی خرید جدید'};
 const nav=[['dashboard','grid'],['register','plus'],['customers','users'],['buyers','briefcase'],['reports','grid'],['finance','briefcase'],['tasks','check'],['team','briefcase']].filter(([id])=>rolePages().includes(id));
 app.innerHTML=`<div class="shell"><aside class="sidebar"><a class="wordmark" href="#${rolePages()[0]}"><img src="/mark.svg" alt="">پارسیان<span>CRM</span></a><div class="workspace-tag"><span class="status-dot"></span> فضای کار تیم فروش <span class="tag">نسخه ۳٫۲</span></div><div class="nav-label">میز کار</div><nav aria-label="ناوبری اصلی">${nav.map(([id,ic])=>`<button class="nav-item ${state.page===id?'active':''}" data-action="navigate" data-page="${id}" aria-label="${labels[id]}" title="${labels[id]}">${icon(ic)}<span>${labels[id]}</span>${id==='tasks'&&due?`<b>${fa(due)}</b>`:''}</button>`).join('')}</nav><div class="sidebar-note">${icon('spark')}<strong>هیچ فرصتی فراموش نشود.</strong><p>هر متقاضی خرید، یک مسئول مشخص.<br>از اولین تماس تا پایان مسیر.</p></div><div class="user-block"><span class="avatar">${esc(currentUser.name[0])}</span><div><strong>${esc(currentUser.name)}</strong><small>${roles[currentUser.role]}</small></div></div></aside><div class="main"><header class="topbar"><span class="breadcrumb">فضای کار <span>/</span> <strong>${labels[state.page]}</strong></span><div class="top-actions"><button type="button" class="secondary" data-action="logout" aria-label="خروج از حساب" title="خروج از حساب">${icon('logout')} خروج</button><button class="icon-btn" data-action="refresh" title="به‌روزرسانی اطلاعات تیم" aria-label="به‌روزرسانی اطلاعات تیم">${icon('clock')}</button><span class="today">${icon('calendar')}${new Intl.DateTimeFormat('fa-IR-u-ca-persian',{weekday:'long',day:'numeric',month:'long',timeZone:'Asia/Tehran'}).format(new Date())}</span>${currentUser.role!=='secretary'?`<button class="icon-btn notification" data-action="navigate" data-page="tasks" title="پیگیری‌های سررسیدشده">${icon('bell')}${due?'<i></i>':''}</button>`:''}<span class="avatar small">${esc(currentUser.name[0])}</span></div></header><main class="content" id="content">${state.page==='register'?registrationPage():state.page==='dashboard'?dashboard():state.page==='customers'?customersPage():state.page==='buyers'?buyersPage():state.page==='finance'?financialPage():state.page==='reports'?reportPage():state.page==='tasks'?tasksPage():teamPage()}</main><footer>پارسیان <span>•</span> ارتباط بهتر، آینده روشن‌تر <span class="footer-left">مدیریت ارتباط با متقاضی خرید</span></footer></div></div>`;
}
function heading(title,sub,action=''){return `<div class="page-heading"><div><span class="eyebrow">${state.page==='dashboard'?'مرکز فرمان فروش':'فضای کار پارسیان'}</span><h1>${title}</h1><p>${sub}</p></div>${action}</div>`;}
const addButton=()=>canRegister()?`<button class="primary" data-action="new-customer">${icon('plus')} متقاضی خرید جدید</button>`:'';
function dashboard(){
 const all=data.customers,active=all.filter(c=>!['won','lost'].includes(c.stage)), overdue=openTasks().filter(t=>t.due<today()),todayTasks=openTasks().filter(t=>t.due===today()),hot=active.filter(c=>c.readiness==='hot'),won=all.filter(c=>c.stage==='won');
 const stats=[['متقاضیان خرید فعال',active.length,'users','green','در مسیر ارتباط و پیگیری'],['پیگیری‌های امروز',todayTasks.length,'calendar','blue',`${fa(overdue.length)} کار عقب‌افتاده`],['فرصت‌های گرم',hot.length,'spark','orange','آماده قدم بعدی فروش'],['قراردادهای موفق',won.length,'check','purple','نتیجه ارتباط‌های ماندگار']];
 return heading(`سلام، ${esc(currentUser.name.split(' ')[0])} <span class="hello">✦</span>`,`امروز فرصت خوبی برای ساختن یک ارتباط تازه است.`,addButton())+`<div class="stats">${stats.map(([label,n,ic,color,desc])=>`<article class="stat-card"><div class="stat-top"><span>${label}</span><span class="stat-icon ${color}">${icon(ic)}</span></div><strong class="stat-number">${fa(n)}</strong><div class="stat-caption"><span class="tiny-dot ${color}"></span>${desc}</div></article>`).join('')}</div><div class="dashboard-grid"><section class="panel followup-panel"><div class="panel-head"><div><h2>نوبت یک ارتباط تازه</h2><p>پیگیری‌های سررسیدشده و کارهای امروز</p></div><button class="text-btn" data-action="navigate" data-page="tasks">همه پیگیری‌ها ${icon('arrow')}</button></div>${taskList([...overdue,...todayTasks].slice(0,5))}</section><section class="panel funnel-panel"><div class="panel-head"><div><h2>مسیر فروش</h2><p>هر متقاضی خرید، یک قدم نزدیک‌تر</p></div>${icon('filter')}</div><div class="funnel">${[['new','ثبت و نیازسنجی'],['technical','مشاوره فنی'],['followup','پیگیری فروش'],['visit','بازدید کارخانه'],['quote','پیش‌فاکتور'],['contract','جلسه قرارداد']].map(([s,label],i)=>{const n=active.filter(c=>s==='new'?['new','discovery'].includes(c.stage):s==='followup'?['followup','longterm'].includes(c.stage):c.stage===s).length;return `<div class="funnel-row"><span class="step-number">${fa(i+1)}</span><div><div class="funnel-label"><span>${label}</span><b>${fa(n)}</b></div><progress value="${n}" max="${Math.max(active.length,1)}" aria-label="${label}"></progress></div></div>`;}).join('')}</div><div class="funnel-foot">${icon('shield')} ${fa(active.length)} متقاضی خرید در مسیر فروش شما</div></section></div><section class="panel"><div class="panel-head"><div><h2>آخرین متقاضیان خرید</h2><p>نگاهی به تازه‌ترین پرونده‌های شما</p></div><button class="text-btn" data-action="navigate" data-page="customers">همه متقاضیان خرید ${icon('arrow')}</button></div>${customerTable([...all].sort((a,b)=>b.updated.localeCompare(a.updated)).slice(0,5))}</section>${!all.length?`<div class="onboarding-strip"><span class="stat-icon green">${icon('spark')}</span><div><strong>اولین فرصت فروش را ثبت کنید</strong><p>کد متقاضی خرید، کار نیازسنجی و تاریخچه پرونده به‌صورت خودکار ساخته می‌شوند.</p></div>${addButton()}</div>`:''}`;
}
function empty(title,sub,ic='users'){return `<div class="empty"><span class="empty-icon">${icon(ic)}</span><strong>${title}</strong><p>${sub}</p></div>`;}
function customerTable(rows){if(!rows.length)return empty('هنوز متقاضی خرید‌ای اینجا نیست','متقاضی خرید جدید ثبت کنید یا فیلترهای جست‌وجو را تغییر دهید.');return `<div class="table-scroll"><table><thead><tr><th>متقاضی خرید / کد پرونده</th><th>حوزه کاری / محصول</th><th>مرحله فعلی</th><th>آمادگی خرید</th><th>کارشناس فروش</th><th>پیگیری بعدی</th><th></th></tr></thead><tbody>${rows.map(c=>{const next=openTasks().find(t=>t.customer_id===c.id);return `<tr><td><button class="customer-link" data-action="customer" data-id="${c.id}"><span class="avatar customer-avatar">${esc(c.name[0])}</span><span><strong>${esc(contactName(c))}</strong><small dir="ltr">${esc(c.code)} · ${esc(c.phone)}</small></span></button></td><td><strong>${esc(c.industry||'ثبت نشده')}</strong><small>${esc(c.product||'در انتظار نیازسنجی')}</small></td><td>${badge(c.stage)}</td><td>${badge(c.readiness,'readiness')}</td><td><span class="owner-name"><span class="avatar tiny">${esc(userName(c.salesId)[0])}</span>${esc(userName(c.salesId))}</span></td><td><span class="${next&&next.due<today()?'overdue':''}">${next?displayDate(next.due):'—'}</span>${next?`<small>${esc(next.title)}</small>`:''}${next&&currentUser.role==='manager'?panelButton('reschedule','ویرایش تاریخ',next.id):''}</td><td><button class="icon-btn" data-action="customer" data-id="${c.id}" aria-label="پرونده ${esc(contactName(c))}">${icon('arrow')}</button></td></tr>`;}).join('')}</tbody></table></div>`;}
function filteredCustomers(){const q=digits(state.search).toLowerCase();return data.customers.filter(c=>(!state.stage||c.stage===state.stage)&&(!state.readiness||c.readiness===state.readiness)&&(!state.owner||c.salesId===Number(state.owner))&&(!q||[c.name,c.company,c.code,c.phone,c.messengerNumber,c.industry,c.product,c.address].some(v=>digits(v||'').toLowerCase().includes(q)))).sort((a,b)=>state.sort==='name'?a.name.localeCompare(b.name,'fa'):['phone','industry','product','stage'].includes(state.sort)?String(a[state.sort]||'').localeCompare(String(b[state.sort]||''),'fa'):state.sort==='firstContact'?b.firstContact.localeCompare(a.firstContact):state.sort==='purchaseDate'?(a.purchaseDate||'9999').localeCompare(b.purchaseDate||'9999'):state.sort==='readiness'?['hot','warm','cold'].indexOf(a.readiness)-['hot','warm','cold'].indexOf(b.readiness):state.sort==='nextDate'?(openTasks().find(t=>t.customer_id===a.id)?.due||'9999').localeCompare(openTasks().find(t=>t.customer_id===b.id)?.due||'9999'):b.updated.localeCompare(a.updated));}
function customersPage(){const rows=filteredCustomers();return heading('متقاضیان خرید','همه ارتباط‌ها، اطلاعات و فرصت‌های فروش در یک نگاه.',addButton())+`<section class="panel"><div class="filterbar"><div class="search-box">${icon('search')}<input id="search" aria-label="جست‌وجوی متقاضی خرید" placeholder="جست‌وجوی نام، شماره، محصول یا کد متقاضی خرید…" value="${esc(state.search)}"></div>${spreadsheetButtons('leads')}</div><div class="filters">${filterSelect('stage','همه مراحل',Object.entries(stages))}${filterSelect('readiness','همه سطح‌ها',Object.entries(readiness))}${filterSelect('owner','همه کارشناسان',data.users.filter(u=>u.active&&u.role==='sales'||data.customers.some(c=>c.salesId===u.id)).map(u=>[u.id,u.name]))}${filterSelect('sort','مرتب‌سازی',[['updated','آخرین تغییر'],['name','نام متقاضی خرید'],['phone','شماره تماس'],['industry','حوزه کاری'],['product','محصول'],['stage','مرحله فروش'],['firstContact','تاریخ ارتباط اولیه'],['purchaseDate','زمان احتمالی خرید'],['readiness','آمادگی خرید'],['nextDate','موعد پیگیری']])}<span class="result-count">${fa(rows.length)} متقاضی خرید</span></div><div id="customer-results">${customerTable(rows)}</div></section>`;}
function filterSelect(key,label,options){return `<select class="filter-select" data-filter="${key}" aria-label="${label}">${key==='sort'?'':`<option value="">${label}</option>`}${options.map(([v,l])=>`<option value="${esc(v)}" ${String(state[key])===String(v)?'selected':''}>${esc(l)}</option>`).join('')}</select>`;}
function taskList(tasks){
 if(!tasks.length)return empty('همه‌چیز مرتب است','در این بخش کار بازی ندارید. پیگیری‌های آینده را هم می‌توانید ببینید.','check');
 return `<div class="task-list">${tasks.map(t=>{
  const c=data.customers.find(c=>c.id===t.customer_id);if(!c)return '';
  const late=t.due<today(), allowed=currentUser.role!=='director'&&(currentUser.role==='manager'||t.owner_id===currentUser.id);
  return `<div class="task-row">${allowed?`<button class="task-check" data-action="task" data-id="${t.id}" aria-label="ثبت نتیجه ${esc(t.title)}">${icon('check')}</button>`:`<span class="task-check">${icon('clock')}</span>`}<div class="task-info"><button data-action="customer" data-id="${c.id}">${esc(t.title)}</button><small>${esc(contactName(c))} <span>·</span> ${esc(userName(t.owner_id))}</small></div><span class="task-date ${late?'overdue':''}">${icon('clock')}${t.due===today()?'امروز':displayDate(t.due)}${late?'<small>عقب‌افتاده</small>':''}</span>${currentUser.role==='manager'?panelButton('reschedule','تغییر موعد',t.id):''}<button class="icon-btn" data-action="${allowed?'task':'customer'}" data-id="${allowed?t.id:c.id}" aria-label="جزئیات کار">${icon('arrow')}</button></div>`;
 }).join('')}</div>`;
}
function tasksPage(){const tabs=[['today','امروز'],['overdue','عقب‌افتاده'],['upcoming','۷ روز آینده'],['all','همه کارهای باز'],['done','انجام‌شده']].filter(([id])=>currentUser.role!=='technical'||id!=='done');const tasks=data.tasks.filter(t=>(!state.tasksMine||t.owner_id===currentUser.id)&&(state.taskFilter==='done'?t.state==='done':t.state==='open'&&(state.taskFilter==='all'||state.taskFilter==='today'&&t.due===today()||state.taskFilter==='overdue'&&t.due<today()||state.taskFilter==='upcoming'&&t.due>today()&&t.due<=plus(today(),7))));return heading(currentUser.role==='technical'?'تیکت‌های فنی من':'پیگیری‌ها و یادآوری‌ها',currentUser.role==='technical'?'پاسخ هر تیکت، پرونده را به کارشناس فروش مسئول برمی‌گرداند.':'قدم بعدی هر متقاضی خرید را به‌موقع بردارید.')+`<section class="panel"><div class="task-toolbar"><div class="tabs">${tabs.map(([id,label])=>`<button class="tab ${state.taskFilter===id?'selected':''}" data-action="task-tab" data-tab="${id}">${label}</button>`).join('')}</div><label class="check-label"><input id="mine" type="checkbox" ${state.tasksMine?'checked':''}>فقط کارهای من</label></div>${state.taskFilter==='done'?tasks.length?`<div class="task-list">${tasks.map(t=>`<div class="task-row"><span class="stat-icon green">${icon('check')}</span><div class="task-info"><strong>${esc(t.title)}</strong><small>${esc(contactName(data.customers.find(c=>c.id===t.customer_id)))}</small></div><button class="text-btn" data-action="customer" data-id="${t.customer_id}">پرونده ${icon('arrow')}</button></div>`).join('')}</div>`:empty('هنوز کاری انجام نشده','نتیجه کارها را ثبت کنید تا در این بخش دیده شوند.','check'):taskList(tasks)}</section><div class="hint">${icon('bell')} یادآوری‌ها درون اپ نمایش داده می‌شوند؛ ارسال پیامک یا اعلان بیرون از اپ در این نسخه فعال نیست.</div>`;}
function teamPage(){return heading('یک تیم، یک مسیر','مسئولیت روشن، همکاری بهتر و ارتباط‌های مؤثرتر.',currentUser.role==='manager'?`<button class="primary" data-action="new-user">${icon('plus')} افزودن همکار</button>`:'')+panelButton('audit','سابقه تغییرات',0)+`<div class="team-grid">${data.users.filter(u=>u.active).map(u=>`<article class="panel member-card"><span class="avatar member-avatar">${esc(u.name[0])}</span><h2>${esc(u.name)}</h2><span class="badge ${u.role==='technical'?'technical':'followup'}">${roles[u.role]}</span><p dir="ltr">@${esc(u.username)}</p><div class="member-stats"><div><strong>${fa(data.customers.filter(c=>c.salesId===u.id||c.technicalId===u.id).length)}</strong><small>پرونده مرتبط</small></div><div><strong>${fa(openTasks().filter(t=>t.owner_id===u.id&&t.due<today()).length)}</strong><small>کار عقب‌افتاده</small></div></div>${currentUser.role==='manager'?panelButton('member-edit','ویرایش',u.id)+(u.id!==currentUser.id?panelButton('member-delete','حذف عضو',u.id):''):''}</article>`).join('')}</div><div class="hint">${icon('shield')} مدیر به همه پرونده‌ها دسترسی دارد. کارشناسان فقط پرونده‌هایی را می‌بینند که به آن‌ها اختصاص داده شده است.</div>`;}
let profileContext=null;
function dismissModal(){
 const parent=profileContext;
 if(parent&&modal.querySelector('form')){
   if(parent.kind==='buyer')buyerDetail(parent.id);else customerDetail(parent.id);
 }else{profileContext=null;modal.close();}
}
modal.addEventListener('cancel',e=>{e.preventDefault();dismissModal();});
function showModal(title,content,cls=''){if(!modal.open)profileContext=null;modal.className=cls;modal.innerHTML=`<div class="modal-head"><h2 id="modal-title">${title}</h2><button class="icon-btn" data-action="close-modal" aria-label="بستن">${icon('close')}</button></div>${content}`;if(!modal.open)modal.showModal();}
const formEnd=label=>`<p class="form-error full" role="alert"></p><div class="form-actions full"><button class="primary" type="submit">${label}</button><button class="secondary" type="button" data-action="close-modal">انصراف</button></div>`;
function registrationMarkup(c={},inline=false){
 const edit=Boolean(c.id), sales=data.users.filter(u=>u.active&&u.role==='sales');
 return `<form id="customer-form" data-id="${c.id||''}" class="form-grid"><div class="form-intro full">${icon('users')} ${edit?'کارشناس فروش تعیین‌شده تا پایان پرونده ثابت است.':'کد متقاضی خرید، تاریخ ثبت و کار تماس اولیه خودکار ساخته می‌شوند.'}</div>${input('name','نام و نام خانوادگی متقاضی خرید *',c.name,'text',true)}${input('phone','شماره متقاضی خرید *',c.phone,'tel',true)}${edit?`<label class="full">کارشناس فروش ثابت<input value="${esc(userName(c.salesId))}" readonly aria-readonly="true"><input type="hidden" name="salesId" value="${c.salesId}"></label>`:select('salesId','تخصیص به کارشناس فروش *',[['','انتخاب کارشناس فروش'],...sales.map(u=>[u.id,u.name])],currentUser.role==='sales'?currentUser.id:'',true)}<label class="full">توضیحات ثبت اولیه<textarea name="registrationNotes" rows="3">${esc(c.registrationNotes)}</textarea></label>${!sales.length&&!edit?`<p class="hint full">هنوز کارشناس فروش تعریف نشده است.${currentUser.role==='manager'?' ابتدا از بخش اعضای تیم یک کارشناس فروش اضافه کنید.':' از مدیر فروش بخواهید کارشناس فروش تعریف کند.'}</p>`:''}<p class="form-error full" role="alert"></p><div class="form-actions full"><button class="primary" type="submit" ${!sales.length&&!edit?'disabled':''}>${edit?'ذخیره تغییرات':'ثبت متقاضی خرید'}</button>${inline?'':`<button class="secondary" type="button" data-action="close-modal">انصراف</button>`}</div></form>`;
}
function registrationPage(){return heading('ثبت متقاضی خرید جدید','اطلاعات اولیه را ثبت و متقاضی خرید را به کارشناس فروش تخصیص دهید.')+`<section class="panel registration-panel">${registrationMarkup({},true)}</section>`;}
function customerForm(c={}){showModal(c.id?'ویرایش اطلاعات ثبت اولیه':'ثبت متقاضی خرید جدید',registrationMarkup(c));}
function deviceRow(d={},contract=false){
 return `<div class="device-row"><div class="device-header"><strong>دستگاه</strong><button type="button" class="icon-btn" data-action="remove-device" aria-label="حذف دستگاه">${icon('close')}</button></div><div class="device-fields">${deviceInputs(d,contract)}</div></div>`;
}
function discoveryFields(c={}){
 return `${input('messengerNumber','شماره پیام‌رسان',c.messengerNumber,'tel')}${select('messengerType','نوع پیام‌رسان',[['','انتخاب کنید'],...['واتساپ','تلگرام','ایتا','بله','روبیکا','سایر'].map(t=>[t,t])],c.messengerType)}${input('company','نام شرکت',c.company)}${input('address','آدرس متقاضی خرید',c.address)}${input('position','سمت متقاضی خرید',c.position)}${input('industry','حوزه کاری *',c.industry,'text',true)}${input('product','محصول موردنظر برای تولید *',c.product,'text',true)}${sourceFields(c)}${select('readiness','آمادگی خرید',Object.entries(readiness),c.readiness||'cold')}<div class="full devices-section"><div class="devices-heading"><h3>دستگاه‌های موردنیاز و قیمت اعلامی</h3><button type="button" class="secondary" data-action="add-device">${icon('plus')} افزودن دستگاه</button></div><div id="device-rows">${(c.devices?.length?c.devices:[{}]).map(d=>deviceRow(d)).join('')}</div></div>`;
}
function devicesDetail(c){return (c.devices||[]).map((d,i)=>`<article class="device-summary"><strong>${fa(i+1)}. ${esc(d.name)}</strong>${detailPairs([['تناژ',d.tonnage],['ویژگی فنی',d.technicalFeatures],['قیمت اعلامی',typeof d.quotedPrice==='number'?priceLabel(d.quotedPrice):d.quotedPrice]])}</article>`).join('')||'<p class="general-note">هنوز دستگاهی ثبت نشده است.</p>';}
async function customerDetail(id){
 state.selected=Number(id);const c=data.customers.find(c=>c.id===Number(id));if(!c)return;
 if(currentUser.role==='technical'){const t=openTasks().find(t=>t.customer_id===c.id&&t.kind==='technical');if(t)actionForm('complete',t.id);return;}
 showModal('پرونده متقاضی خرید','<div class="detail-loading">در حال دریافت تاریخچه…</div>','detail-modal');
 try{
  const {events}=await api(`customers/${id}/events`);if(state.selected!==Number(id)||!modal.open)return;shownEvents=events;
  const tasks=openTasks().filter(t=>t.customer_id===c.id),closed=['won','lost'].includes(c.stage),waiting=c.stage==='technical';
  showModal('پرونده متقاضی خرید',`<div class="customer-profile"><span class="avatar profile-avatar">${esc(c.name[0])}</span><div><h2>${esc(contactName(c))}</h2><span dir="ltr">${c.code}</span></div><div class="profile-badges">${badge(c.stage)}${badge(c.readiness,'readiness')}</div>${canSell()?`<button class="secondary" data-action="edit-customer"  data-id="${c.id}">${icon('edit')} ویرایش ثبت اولیه</button>`:''}${currentUser.role==='manager'?panelButton('delete-lead','حذف متقاضی',id):''}</div><div class="detail-columns"><div class="detail-main"><section class="detail-section"><h3>اقدام‌های پرونده</h3><div class="action-buttons">${canSell()?`<button class="secondary" data-action="action-form"  data-type="note">${icon('plus')} یادداشت</button>${!closed?`${!waiting?`<button class="secondary" data-action="action-form" data-type="technical">مشاوره فنی</button><button class="secondary" data-action="action-form" data-type="visit">بازدید کارخانه</button><button class="secondary" data-action="action-form" data-type="quote">پیش‌فاکتور</button><button class="secondary" data-action="action-form" data-type="contract">جلسه قرارداد</button>`:''}<button class="secondary" data-action="action-form" data-type="close">بستن پرونده</button>`:`<button class="secondary" data-action="action-form" data-type="reopen">بازگشایی پرونده</button>`}` : ''}</div>${waiting?'<p class="hint">کارهای فروش تا پاسخ تیکت فنی در انتظار می‌مانند و سپس با همان کارشناس فروش ادامه پیدا می‌کنند.</p>':''}</section><section class="detail-section"><h3>کارهای باز <span class="tag">${fa(tasks.length)}</span></h3>${taskList(tasks)}</section><section class="detail-section"><h3>دستگاه‌ها و قیمت‌های اعلامی</h3>${devicesDetail(c)}</section><section class="detail-section"><h3>تاریخچه ارتباط‌ها</h3><div class="timeline">${events.map(e=>`<article class="timeline-event"><span class="timeline-dot"></span><div><div class="event-title"><strong>${esc(e.type)}</strong><time>${jalali(e.created.slice(0,10))}</time></div><p>${esc(e.note.replace(/\b\d{4}-\d{2}-\d{2}\b/g,d=>{try{return jalali(d);}catch{return d;}}))}</p>${e.details.sendNumber?`<p>ارسال پیش‌فاکتور شماره ${fa(e.details.sendNumber)}</p>`:''}${e.filename?`<a href="/api/attachments/${e.id}" download>${esc(e.filename)}</a>`:''}${e.details.actualDate?`<p>تاریخ انجام ${jalali(e.details.actualDate)}</p>`:''}${e.details.meetingResult?`<p>${esc(({held:'جلسه برگزار شد',signed:'قرارداد امضا شد',noShow:'حاضر نشد',cancelled:'لغو شد'})[e.details.meetingResult])}</p>`:''}${e.details.scheduledDate?`<p>تاریخ جلسه ${jalali(e.details.scheduledDate)} ${esc(e.details.time||'')}</p>`:''}${e.details.nextDate?`<p>موعد پیگیری ${jalali(e.details.nextDate)}</p>`:''}${e.details.quoteNumber?`<p>شماره پیش‌فاکتور ${esc(e.details.quoteNumber)}</p>`:''}${canSell()&&e.user_id===currentUser.id&&!e.type.startsWith('ویرایش')?panelButton('stage-edit','ویرایش مرحله',e.id):''}<small>${esc(e.author)} · ${new Intl.DateTimeFormat('fa-IR',{hour:'2-digit',minute:'2-digit',timeZone:'Asia/Tehran'}).format(new Date(e.created))}</small></div></article>`).join('')}</div></section></div><aside class="detail-aside"><h3>روند آمادگی خرید</h3>${readinessPlot(c.readinessHistory)}<h3>اطلاعات متقاضی خرید</h3>${detailPairs([['نام شرکت',c.company],['شماره تماس',c.phone],['پیام‌رسان',`${c.messengerType||'—'} ${c.messengerNumber||''}`],['سمت',c.position],['آدرس',c.address],['ارتباط اولیه',jalali(c.firstContact)],['کارشناس فروش ثابت',userName(c.salesId)],['آخرین کارشناس فنی',userName(c.technicalId)]])}<h3>نیازسنجی و فروش</h3>${detailPairs([['حوزه کاری',c.industry],['محصول',c.product],['نحوه آشنایی',c.source],['نام معرف',c.referrer],['تعداد ارسال پیش‌فاکتور',fa(c.quoteCount)],['زمان احتمالی خرید',jalali(c.purchaseDate)],['تماس‌های پیگیری',`${fa(c.followupCount)} تماس مؤثر`],['پیش‌فاکتور',quoteLabels[c.quoteStatus]||'ثبت نشده'],['شماره پیش‌فاکتور',c.quoteNumber],['تاریخ ارسال',jalali(c.quoteDate)]])}<h3>توضیحات ثبت اولیه</h3><p class="general-note">${esc(c.registrationNotes||'ثبت نشده')}</p><h3>توضیحات تماس اولیه</h3><p class="general-note">${esc(c.discoveryNotes||c.generalNotes||'هنوز ثبت نشده')}</p>${c.closeReason?`<h3>نتیجه پرونده</h3><p class="general-note">${esc(c.closeReason)}</p>`:''}</aside></div>`,'detail-modal');
 profileContext={kind:'lead',id:c.id};
 }catch(e){toast(e.message,true);}
}
function detailPairs(pairs){return `<dl>${pairs.map(([k,v])=>`<div><dt>${k}</dt><dd>${esc(v||'—')}</dd></div>`).join('')}</dl>`;}
function actionForm(type,taskId){
 const t=taskId?data.tasks.find(t=>t.id===Number(taskId)):null;
 const customer=data.customers.find(c=>c.id===(t?t.customer_id:state.selected));if(!customer)return;
 state.selected=customer.id;
 const titles={note:'یادداشت جدید',technical:'درخواست مشاوره فنی',visit:'برنامه‌ریزی بازدید کارخانه',quote:'وضعیت پیش‌فاکتور',contract:'جلسه عقد قرارداد',close:'ثبت نتیجه و بستن پرونده',reopen:'بازگشایی پرونده',complete:t?.title,reschedule:'تغییر موعد کار'};
 let fields='';
 if(type==='complete'){
  if(t.kind==='technical')fields+=`<section class="full ticket-context"><h3>درخواست مشاوره فنی</h3><p>${esc(customer.technicalRequest||'درخواست فنی ثبت‌شده قبلی')}</p>${detailPairs([['متقاضی خرید',contactName(customer)],['شماره تماس',customer.phone],['کارشناس فروش مسئول',userName(customer.salesId)],['حوزه کاری',customer.industry],['محصول',customer.product]])}${(customer.devices||[]).map(d=>`<p>${esc(d.name)} — ${esc(d.tonnage)} — ${esc(d.technicalFeatures)}</p>`).join('')}</section>`;
  fields+=dateInput('actualDate','تاریخ واقعی انجام *',today(),true);
  if(['visit','contract'].includes(t.kind))fields+=select('meetingResult','نتیجه جلسه',[['held','برگزار شد'],...(t.kind==='contract'?[['signed','قرارداد امضا شد']]:[]),['cancelled','لغو شد'],['noShow','متقاضی خرید حاضر نشد']],'held');
  if(['discovery','followup'].includes(t.kind))fields+=select('result','نتیجه تماس',[['success','تماس موفق'],['noanswer','پاسخ نداد'],['later','درخواست تماس در زمان دیگر'],['invalid','شماره نامعتبر']],'success');
  if(t.kind==='discovery')fields+=`<fieldset class="full form-grid" id="discovery-fields">${discoveryFields(customer)}</fieldset>`;
  if(t.kind==='followup')fields+=select('readiness','آمادگی خرید در این تماس *',[['','انتخاب کنید'],...Object.entries(readiness)],'',true)+dateInput('purchaseDate','زمان احتمالی خرید',customer.purchaseDate);
  if(['discovery','followup'].includes(t.kind))fields+=dateInput('nextDate','موعد تماس بعدی *',plus(today(),t.kind==='discovery'?7:2),true);
  fields+=note(['introduction','trust'].includes(t.kind)?'توضیحات ارسال':t.kind==='discovery'?'توضیحات تماس اولیه *':t.kind==='technical'?'پاسخ و نتیجه مشاوره فنی *':'توضیحات و نتیجه *',t.kind==='discovery'?(customer.discoveryNotes||customer.generalNotes||''):'');
  if(['introduction','trust'].includes(t.kind))fields+=`<p class="hint full">${t.kind==='introduction'?'ثبت این مرحله، ارسال کاتالوگ و فیلم معرفی کارخانه را با هم تأیید می‌کند. ':''}ارسال محتوا توسط خود کارشناس انجام می‌شود.</p>`;
  if(t.kind==='technical')fields+=`<p class="hint full">پس از ثبت پاسخ، تیکت بسته و پرونده به ${esc(userName(customer.salesId))} برگردانده می‌شود.</p>`;
 }else if(type==='close')fields+=select('outcome','نتیجه نهایی',[['lost','عدم خرید / انصراف'],['won','قرارداد منعقد شده']])+note('علت بستن پرونده و نتیجه *');
 else if(type==='quote')fields+=select('quoteStatus','وضعیت پیش‌فاکتور',Object.entries(quoteLabels),customer.quoteStatus||'pending')+input('quoteNumber','شماره پیش‌فاکتور',customer.quoteNumber)+dateInput('sentDate','تاریخ ارسال',customer.quoteDate||today())+`<label>فایل پیش‌فاکتور (حداکثر ۵ مگابایت)<input type="file" name="upload"></label><p>تعداد ارسال‌های قبلی: ${fa(customer.quoteCount)}</p>`+note('جزئیات پیش‌فاکتور *');
 else if(type==='technical')fields+=select('technicalId','تخصیص تیکت به کارشناس فنی *',[['','انتخاب کارشناس فنی'],...data.users.filter(u=>u.active&&u.role==='technical').map(u=>[u.id,u.name])],customer.technicalId||'',true)+note('موضوع مشاوره و پرسش‌های متقاضی خرید *');
 else{
  if(['visit','contract'].includes(type))fields+=dateInput('scheduledDate',type==='visit'?'تاریخ بازدید کارخانه *':'تاریخ جلسه قرارداد *',plus(today(),1),true)+input('time','ساعت جلسه','','time',true);
  if(['reopen','reschedule'].includes(type))fields+=dateInput('nextDate',type==='reopen'?'موعد پیگیری *':'موعد جدید *',t?.due||plus(today(),1),true);
  fields+=note(type==='reschedule'?'علت تغییر موعد *':'توضیحات *');
 }
 showModal(titles[type],`<form id="action-form" data-type="${type}" data-customer="${customer.id}" data-task="${t?.id||''}" class="form-grid"><div class="form-intro full">${icon('file')} ${esc(contactName(customer))} <span dir="ltr">${customer.code}</span></div>${fields}${type==='complete'&&t&&t.kind!=='technical'?`<button type="button" class="text-btn full" data-action="reschedule" data-id="${t.id}">انجام نشده؛ تغییر موعد این کار</button>`:''}${formEnd(t?.kind==='technical'?'ثبت پاسخ و بازگشت به فروش':type==='close'?'ثبت نتیجه نهایی':'ثبت و ذخیره')}</form>`);
 if(type==='complete'&&['introduction','trust'].includes(t.kind))$('textarea',modal).required=false;
}
function newUser(){showModal('افزودن همکار به تیم',`<form id="user-form" class="form-grid">${input('name','نام و نام خانوادگی *','','text',true)}${input('username','نام کاربری انگلیسی *','','text',true)}${input('password','رمز عبور (حداقل ۸ حرف) *','','password',true)}${select('role','نقش همکار',Object.entries(roles),'sales')}<p class="hint full">کارشناس پذیرش فقط ثبت متقاضی خرید، فروش پرونده‌های خودش، فنی فقط تیکت فعال خودش و مدیر فروش همه پرونده‌ها را مدیریت می‌کند.</p>${formEnd('افزودن همکار')}</form>`);}

let calendarTarget, calY, calM;
const monthNames=['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
function openCalendar(input){calendarTarget=input;let iso;try{iso=fromJalali(input.value)||today();}catch{iso=today();}const p=parts(iso);calY=p.y;calM=p.m;renderCalendar();if(!calendar.open)calendar.showModal();}
function renderCalendar(){const first=fromJalali(`${calY}/${calM}/1`), offset=(new Date(first+'T12:00:00Z').getUTCDay()+1)%7;let days=[];for(let d=0;d<31;d++){const iso=plus(first,d);if(parts(iso).m!==calM)break;days.push(iso);}calendar.innerHTML=`<div class="calendar-head"><button class="icon-btn" data-action="cal-prev" aria-label="ماه قبل">${icon('chevron')}</button><strong>${monthNames[calM-1]} ${fa(calY)}</strong><button class="icon-btn" data-action="cal-next" aria-label="ماه بعد">${icon('arrow')}</button></div><div class="calendar-grid">${['ش','ی','د','س','چ','پ','ج'].map(d=>`<span>${d}</span>`).join('')}${Array.from({length:offset},()=>'<span></span>').join('')}${days.map((iso,i)=>`<button class="calendar-day ${iso===today()?'is-today':''}" data-action="cal-pick" data-date="${iso}" type="button">${fa(i+1)}</button>`).join('')}</div><div class="calendar-footer"><button class="text-btn" data-action="cal-pick" data-date="${today()}">امروز</button><button class="text-btn" data-action="cal-close">بستن</button></div>`;}
const leadColumns=[['code','کد متقاضی خرید'],['name','نام'],['company','نام شرکت'],['referrer','نام معرف'],['phone','شماره تماس'],['messengerNumber','شماره پیام‌رسان'],['messengerType','نوع پیام‌رسان'],['address','آدرس'],['position','سمت'],['firstContact','ارتباط اولیه'],['industry','حوزه کاری'],['product','محصول'],['tonnage','تناژ'],['source','نحوه آشنایی'],['readiness','آمادگی'],['purchaseDate','زمان خرید'],['stage','مرحله'],['salesId','کارشناس فروش'],['technicalId','کارشناس فنی'],['registrationNotes','توضیحات ثبت اولیه'],['discoveryNotes','توضیحات تماس اولیه'],['devices','دستگاه‌ها و قیمت‌های اعلامی'],['nextDate','موعد پیگیری'],['followupCount','تعداد تماس پیگیری'],['signed','تاریخ عقد قرارداد']];
const buyerColumns=[['name','نام'],['company','نام شرکت'],['phone','شماره تماس'],['address','آدرس'],['position','سمت'],['firstContact','تاریخ آشنایی'],['source','نحوه آشنایی'],['referrer','نام معرف'],['industry','حوزه کاری'],['product','محصول'],['salesId','کارشناس فروش']];
const dateColumns=['firstContact','purchaseDate','nextDate','signed'];
function spreadsheetButtons(kind){
 return '<button class="secondary" data-action="export" data-sheet="'+kind+'">'+icon('download')+' خروجی CSV</button>'+
 (canSell()?'<button class="secondary" data-action="import" data-sheet="'+kind+'">ورود CSV یا اکسل</button>':'');
}
function exportCSV(kind='leads',template=false){
 const buyers=kind==='buyers',columns=buyers?buyerColumns:leadColumns;
 const rows=template?[]:buyers?filteredBuyers($('#buyer-search')?.value||''):filteredCustomers();
 const cell=v=>'"'+String(v??'').replace(/^[=+@\-\t\r]/,"'$&").replace(/"/g,'""')+'"';
 function value(row,key){
   if(key==='stage')return stages[row.stage];
   if(key==='readiness')return readiness[row.readiness];
   if(['salesId','technicalId'].includes(key))return data.users.find(u=>u.id===row[key])?.username||'';
   if(key==='devices')return JSON.stringify(row.devices||[]);
   if(key==='nextDate')return jalali(data.tasks.find(t=>t.customer_id===row.id&&t.state==='open')?.due);
   if(key==='signed')return jalali(data.buyers.find(b=>b.id===row.buyerId)?.contracts.find(k=>k.leadId===row.id)?.signed);
   if(dateColumns.includes(key))return jalali(row[key]);
   return row[key];
 }
 const csv='\uFEFF'+[columns.map(c=>cell(c[1])).join(','),...rows.map(row=>columns.map(([k])=>cell(value(row,k))).join(','))].join('\r\n');
 const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'})),a=document.createElement('a');
 a.href=url;a.download='parsian-'+kind+'-'+(template?'template':today())+'.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
function importForm(kind){
 const buyers=kind==='buyers';
 const owner=!buyers&&currentUser.role==='manager'?select('defaultOwner','کارشناس فروش برای ردیف‌های بدون کارشناس',[['','انتخاب کنید'],...data.users.filter(u=>u.active&&u.role==='sales').map(u=>[u.username,u.name])]):'';
 recordForm(buyers?'ورود گروهی مشتریان':'ورود گروهی متقاضیان خرید','import',
 '<p class="full">ردیف اول باید عنوان ستون‌ها باشد. ستون‌های ضروری: '+(buyers?'نام و آدرس':'نام، شماره تماس و کارشناس فروش')+'. تاریخ را شمسی وارد کنید و شماره تماس را در اکسل به صورت متن بنویسید. کاربرگ اول خوانده می‌شود (تا ۱۰۰۰ ردیف و ۵ مگابایت).</p>'+
 '<button type="button" class="secondary" data-action="template" data-sheet="'+kind+'">دریافت فایل نمونه CSV</button>'+
 '<label class="full">انتخاب فایل CSV یا XLSX<input name="sheet" required type="file" accept=".csv,.xlsx"></label>'+owner+
 '<p class="full">پرونده‌های تکراری رد می‌شوند. اگر ردیفی نامعتبر باشد، هیچ ردیفی از این فایل ثبت نمی‌شود.</p>',0,'data-sheet="'+kind+'"');
}
function spreadsheetDate(value,epoch1904){
 const v=digits(value);
 if(!v)return '';
 if(/^\d{1,5}(\.\d+)?$/.test(v))return plus(epoch1904?'1904-01-01':Number(v)<60?'1899-12-31':'1899-12-30',Math.floor(Number(v)));
 if(/^\d{4}-\d\d-\d\d$/.test(v)&&Number(v.slice(0,4))>=1900)return v;
 return fromJalali(v);
}
async function importSheet(form){
 const kind=form.dataset.sheet,columns=kind==='buyers'?buyerColumns:leadColumns;
 const matrix=await readSheet(form.elements.sheet.files[0]);
 const keys=Array.from(matrix[0]||[],label=>columns.find(c=>c[1]===String(label||'').trim())?.[0]);
 if(keys.includes(undefined)||new Set(keys).size!==keys.length)throw Error('عنوان تکراری یا ناشناس است. از فایل نمونه همین فهرست استفاده کنید.');
 if(!(kind==='buyers'?['name','address']:['name','phone']).every(k=>keys.includes(k)))throw Error('ستون‌های ضروری در فایل وجود ندارند.');
 const rows=[];
 for(const [index,line] of matrix.slice(1).entries()){
   if(!line.some(v=>String(v??'').trim()))continue;
   try{
     const row={};
     if(line.slice(keys.length).some(v=>String(v??'').trim()))throw Error('یک یا چند سلول عنوان ستون ندارند.');
     for(const [i,k] of keys.entries()){
       let v=String(line[i]??'').trim().replace(/^'(?=[=+@\-])/,'');
       if(dateColumns.includes(k))v=spreadsheetDate(v,matrix.epoch1904);
       if(['phone','messengerNumber'].includes(k)){v=digits(v);if(/^9\d{9}$/.test(v))v='0'+v;}
       if(k==='readiness'||k==='stage'){
         const options=k==='stage'?stages:readiness;
         if(v)v=Object.entries(options).find(([key,label])=>label===v||key===v)?.[0]||v;
       }
       if(['salesId','technicalId'].includes(k)&&v==='—')v='';
       row[k]=v;
     }
     row.salesId||=form.elements.defaultOwner?.value||'';
     rows.push({...row,line:index+2});
   }catch(e){throw Error('ردیف '+fa(index+2)+' · '+e.message);}
 }
 const result=await api('import/'+kind,'POST',{rows});modal.close();await load();
 toast(fa(result.added)+' پرونده وارد شد. '+fa(result.skipped)+' ردیف تکراری بود.');
}
function sourceFields(c,optional=false) {
 const referral=c.source==='معرف';
 return select('source',optional?'نحوه آشنایی':'نحوه آشنایی *',[['','انتخاب کنید'],...data.sources.map(v=>[v,v])],c.source,!optional)+
   `<label class="referrer" ${referral?'':'hidden'}>نام معرف *<input name="referrer" value="${esc(c.referrer)}" ${referral?'required':'disabled'}></label>`;
}
function deviceInputs(c,contract=false) {
 const tonnage=contract?input('deviceTonnage','تناژ دستگاه *',c.tonnage,'number',true):
   select('deviceTonnage','تناژ دستگاه *',[['','انتخاب کنید'],...data.tonnages.map(n=>[n,fa(n)+' تن'])],c.tonnage,true);
 return tonnage+input('deviceFeatures',contract?'مشخصات فنی هر دستگاه *':'ویژگی فنی',c.technicalFeatures,'text',contract)+
   (contract?select('build','نوع دستگاه *',[['standard','استاندارد'],['custom','سفارشی']],c.build||'standard',true)+input('customization','موارد سفارشی‌سازی *',c.customization):`<label>قیمت اعلامی (میلیون تومان)<input name="devicePrice" type="number" min="0" step="any" dir="ltr" value="${esc(typeof c.quotedPrice==='number'?c.quotedPrice:'')}"><output class="price-preview">${esc(typeof c.quotedPrice==='number'?priceLabel(c.quotedPrice):'')}</output></label>`);
}
function buyersPage(){
 const btn=canSell()?'<button class="primary" data-action="buyer-new">ثبت مشتری قبلی</button>':'';
 return heading('مشتریان','پرونده خریداران دستگاه و قراردادهای آن‌ها',btn)+`<section class="panel"><div class="filterbar"><input id="buyer-search" placeholder="جست‌وجوی نام، شرکت یا شماره تماس" aria-label="جست‌وجوی مشتری">${spreadsheetButtons('buyers')}</div><div id="buyer-results">${buyerTable('')}</div></section>`;
}
function filteredBuyers(query){
 return data.buyers.filter(b=>[b.name,b.company,b.phone].some(v=>digits(v||'').includes(digits(query))));
}
function buyerTable(query){
 const rows=filteredBuyers(query);
 if(!rows.length)return empty('مشتری پیدا نشد','مشتری قبلی ثبت کنید یا پس از عقد قرارداد، پرونده را از اینجا باز کنید.');
 return `<div class="table-scroll"><table><thead><tr><th>مشتری</th><th>شرکت</th><th>تماس</th><th>قراردادها</th></tr></thead><tbody>${rows.map(b=>`<tr><td><button class="customer-link" data-action="buyer" data-id="${b.id}">${esc(contactName(b))}</button></td><td>${esc(b.company)}</td><td dir="ltr">${esc(b.phone)}</td><td>${fa(b.contracts.length)}</td></tr>`).join('')}</tbody></table></div>`;
}
const panelButton=(action,label,id,extra='')=>`<button type="button" class="secondary" data-action="${action}" data-id="${Number(id)||0}" ${extra}>${label}</button>`;
function buyerDetail(id){
 const b=data.buyers.find(x=>x.id===Number(id));if(!b)return;
 const controls=canSell()?panelButton('service-new','افزودن خدمت',id)+panelButton('buyer-edit','ویرایش پروفایل',id)+panelButton('contract-new','افزودن قرارداد',id)+panelButton('repeat','درخواست خرید مجدد',id):'';
 showModal('پرونده مشتری',`<section class="record-body"><h2>${esc(contactName(b))}</h2>${detailPairs([['شرکت',b.company],['شماره تماس',b.phone],['سمت',b.position],['تاریخ آشنایی',jalali(b.firstContact)],['نحوه آشنایی',b.source],['معرف',b.referrer],['آدرس',b.address],['حوزه کاری',b.industry],['محصول',b.product],['کارشناس فروش',userName(b.salesId)]])}<h3>روند آمادگی خرید</h3>${readinessPlot(data.customers.filter(c=>c.buyerId===b.id).flatMap(c=>c.readinessHistory||[]))}<div class="action-buttons">${controls}</div><h3>داشبورد مالی مشتری</h3>${financialCards([b])}<h3>خدمات</h3>${b.services.map(r=>serviceCard(b,r)).join('')||'خدمتی ثبت نشده است.'}<h3>قراردادها</h3>${b.contracts.map(k=>`<article class="device-summary"><strong>قرارداد ${fa(k.id)} ${k.complete?'':'· نیاز به تکمیل'}</strong>${detailPairs([['تاریخ عقد',jalali(k.signed)],['موعد تحویل',jalali(k.delivery)],['تحویل واقعی',jalali(k.actualDelivery)],['علت تأخیر',k.delayReason],['لوازم جانبی',k.accessories],['نحوه پرداخت',k.payment]])}${(k.devices||[]).map(d=>`<p>${esc(d.tonnage)} تن · ${esc(d.technicalFeatures)} · ${esc(d.build==='custom'?'سفارشی · '+d.customization:d.build==='standard'?'استاندارد':'نوع ثبت نشده')}</p>`).join('')}${receiptSummary(k)}${fileLink(k.file)}<p>تحویل: ${k.actualDelivery?'انجام شده':'در انتظار'}</p>${canSell()&&k.delivery?panelButton('deliver','ثبت / ویرایش تحویل',id,`data-contract="${k.id}"`):''}${canSell()?panelButton('contract-edit','ویرایش قرارداد',id,`data-contract="${k.id}"`):''}</article>`).join('')||'<p>قراردادی ثبت نشده است.</p>'}</section>`,'detail-modal');
 profileContext={kind:'buyer',id:b.id};
}
function recordForm(title,kind,fields,id=0,extra=''){
 showModal(title,`<form id="record-form" class="form-grid" data-kind="${kind}" data-id="${id}" ${extra}>${fields}${formEnd('ذخیره')}</form>`);
}
function buyerForm(id){
 const b=data.buyers.find(x=>x.id===Number(id))||{};
 const sales=data.users.filter(u=>u.active&&u.role==='sales');
 const complete=Boolean(id&&!b.legacy&&b.salesId);
 const field=(key,label,type='text')=>input(key,label+(complete?' *':''),b[key],type,complete);
 recordForm(id?'ویرایش مشتری':'ثبت مشتری قبلی','buyer',input('name','نام و نام خانوادگی *',b.name,'text',true)+field('phone','شماره تماس','tel')+
   ((!id||!b.salesId)&&currentUser.role==='manager'?select('salesId','کارشناس فروش',[['','بدون تخصیص'],...sales.map(u=>[u.id,u.name])],'',false):'')+
   field('company','شرکت')+field('position','سمت')+dateInput('firstContact','تاریخ آشنایی'+(complete?' *':''),b.firstContact,complete)+sourceFields(b,!complete)+input('address','آدرس *',b.address,'text',true)+field('industry','حوزه کاری')+field('product','محصول'),id);
}
const money=n=>Number(n).toLocaleString('fa-IR')+' تومان';
const moneyField=(name,label,value='',required=false)=>`<label>${label}<input name="${name}" type="number" dir="ltr" min="0" step="1" ${required?'required':''} value="${esc(value??'')}"></label>`;
const fileField=label=>`<label class="full">${label} (تا ۵ مگابایت)<input type="file" name="upload"></label>`;
const fileLink=f=>f?`<a href="/api/record-files/${f.id}" download>دریافت ${esc(f.name)}</a>`:'';
function checkRow(c={}){
 return `<div class="check-row form-grid full"><strong>چک</strong>${panelButton('remove-check','حذف چک',0)}
 ${moneyField('checkAmount','مبلغ چک (تومان) *',c.amount,true)}${dateInput('issued','تاریخ صدور *',c.issued,true)}${dateInput('checkDue','تاریخ سررسید *',c.due,true)}
 ${select('status','وضعیت وصول',[['pending','در انتظار'],['cleared','پاس شده'],['unpaid','پاس نشده']],c.status||'pending')}
 ${dateInput('cleared','تاریخ واقعی پاس شدن',c.cleared)}${input('sayad','شماره صیاد',c.sayad)}${input('serial','سری چک',c.serial)}
 ${input('holder','صاحب چک',c.holder)}${input('national','کد ملی صاحب چک',c.national)}</div>`;
}
function paymentFields(r,optional=false){
 const f=r.finance||{},method=f.payment||({'نقدی':'نقد'})[r.payment]||r.payment||'';
 const options=['نقد','چکی','صندوق'].map(v=>[v,v]);
 return select('payment','نحوه پرداخت',[['',optional?'بدون اطلاعات مالی':'انتخاب کنید'],...options],method,!optional)+
 `<fieldset class="full form-grid" data-pay="all">${moneyField('total','مبلغ کل (تومان) *',f.total,true)}
 <label>نرخ بهره مؤثر سالانه (%) *<input type="number" name="rate" min="0" max="10000" step="any" required value="${esc(f.rate??'')}"></label>
 ${moneyField('initialCost','هزینه اولیه در تاریخ مبنا (تومان، اختیاری)',f.initialCost??'')}
 <fieldset class="full form-grid" data-pay="fund"><output class="full" data-fund-plan></output>
 ${select('fundAdvanceStatus','وضعیت پیش‌پرداخت',[['received','دریافت شده'],['pending','در انتظار دریافت']],f.payment==='صندوق'&&!f.advanceDate?'pending':'received')}
 ${dateInput('fundAdvanceDate','تاریخ دریافت پیش‌پرداخت ۳۰٪ *',f.payment==='صندوق'?f.advanceDate:'')}${dateInput('balanceDate','تاریخ دریافت مانده ۷۰٪',f.balanceDate)}
 <small class="full">تاریخ هر بخش را هنگام دریافت ثبت کنید.</small></fieldset>
 <fieldset class="full form-grid" data-pay="simple">${moneyField('collected','مبلغ وصول‌شده (تومان)',f.collected||0)}${dateInput('due','موعد دریافت',f.due)}</fieldset>
 <fieldset class="full form-grid" data-pay="checks">${moneyField('advance','پیش‌پرداخت دریافتی (تومان)',f.advance||0)}${dateInput('advanceDate','تاریخ دریافت پیش‌پرداخت',f.advanceDate)}
 <div class="full checks">${(f.checks||[{}]).map(checkRow).join('')}</div>${panelButton('add-check','افزودن چک',0)}</fieldset></fieldset>`;
}
function syncFinancialForm(form){
 const method=form.elements.payment?.value;
 for(const field of form.querySelectorAll('[data-pay]')){
   const key=field.dataset.pay,visible=!!method&&(key==='all'||key===({'چکی':'checks','صندوق':'fund','نقد':'simple'})[method]);
   field.hidden=field.disabled=!visible;
 }
 for(const row of form.querySelectorAll('.device-row')){
   const extra=row.querySelector('[name=customization]');if(!extra)continue;
   const show=row.querySelector('[name=build]').value==='custom';extra.disabled=!show;extra.required=show;extra.parentElement.hidden=!show;
 }
 if(method==='صندوق'){
   const received=form.elements.fundAdvanceStatus.value==='received';
   const advanceDate=form.elements.fundAdvanceDate;
   advanceDate.required=received;advanceDate.disabled=!received;advanceDate.closest('label').hidden=!received;
   const output=form.querySelector('[data-fund-plan]');
   try{
     const base=fromJalali(form.elements.signed?.value||form.elements.requested?.value||'')||form.dataset.base||today();
     const schedule=fundSchedule(Number(form.elements.total.value)||0,base);
     output.textContent='پیش‌پرداخت: '+money(schedule.advance)+' · مانده: '+money(schedule.balance)+' · سررسید مانده: '+jalali(schedule.due);
   }catch{output.textContent='تاریخ مبنا را وارد کنید.';}
 }
 const dp=form.elements.advanceDate;if(dp)dp.required=Number(form.elements.advance.value)>0&&method==='چکی';
 for(const row of form.querySelectorAll('.check-row')){
   const field=row.querySelector('[name=cleared]'),show=row.querySelector('[name=status]').value==='cleared';field.disabled=!show;field.closest('label').hidden=!show;
 }
}
function serializePayment(form,b){
 if(b.payment==='صندوق')b.advanceDate=b.fundAdvanceDate;
 if(b.payment!=='چکی')return;
 b.checks=$$('.check-row',form).map(row=>{
   const val=name=>row.querySelector('[name="'+name+'"]').value;
   return {amount:val('checkAmount'),issued:fromJalali(val('issued')),due:fromJalali(val('checkDue')),status:val('status'),cleared:val('status')==='cleared'?fromJalali(val('cleared')):'',sayad:val('sayad'),serial:val('serial'),holder:val('holder'),national:val('national')};
 });
}
function receiptSummary(r){
 const s=r.summary;if(!s)return '<p>اطلاعات مالی تکمیل نشده است.</p>';
 return detailPairs([['مبلغ کل',money(s.total)],['وصول‌شده',money(s.received)],['مانده مطالبات',money(s.outstanding)],['ارزش فعلی خالص (NPV)',money(s.present)],['نرخ سالانه',fa(r.finance.rate)+'٪']])+
 (r.finance.payment==='صندوق'?detailPairs([['پیش‌پرداخت صندوق',money(r.finance.advance)],['تاریخ دریافت پیش‌پرداخت',jalali(r.finance.advanceDate)],['مانده صندوق',money(r.finance.balance)],['سررسید مانده',jalali(r.finance.due)],['تاریخ وصول مانده',jalali(r.finance.balanceDate)]]):'')+
 (r.finance.checks||[]).map(c=>`<p>چک ${money(c.amount)} · سررسید ${jalali(c.due)} · ${({pending:'در انتظار',cleared:'پاس شده',unpaid:'پاس نشده'})[c.status]}</p>`).join('');
}
function financialCards(buyers){
 const rows=buyers.flatMap(b=>[...b.contracts,...b.services]);
 const tiles=[['total','مبلغ کل'],['received','وصول‌شده'],['outstanding','مطالبات وصول‌نشده']];
 return `<div class="stats">${tiles.map(([key,label])=>`<article class="stat-card"><span>${label}</span><strong class="finance-number">${money(rows.reduce((sum,r)=>sum+(r.summary?.[key]||0),0))}</strong></article>`).join('')}</div>${rows.some(r=>!r.summary)?`<p>اطلاعات مالی ${fa(rows.filter(r=>!r.summary).length)} مورد تکمیل نشده است.</p>`:''}`;
}
function financialPage(){
 return heading('داشبورد مالی شرکت','دریافت‌ها و مطالبات قراردادها و خدمات')+financialCards(data.buyers)+
 `<section class="panel table-scroll"><table><thead><tr><th>مشتری</th><th>مبلغ کل</th><th>وصول‌شده</th><th>مانده</th></tr></thead><tbody>${data.buyers.map(b=>{
 const entries=[...b.contracts,...b.services];return `<tr><td>${panelButton('buyer',esc(contactName(b)),b.id)}</td>${['total','received','outstanding'].map(k=>`<td>${money(entries.reduce((n,r)=>n+(r.summary?.[k]||0),0))}</td>`).join('')}</tr>`;
 }).join('')}</tbody></table></section>`;
}
function serviceForm(id,sid){
 const r=data.buyers.find(b=>b.id===Number(id)).services.find(x=>x.id===Number(sid))||{};
 recordForm(sid?'ویرایش خدمت':'ثبت خدمت','service',input('type','نوع خدمت *',r.type,'text',true)+input('part','قطعه',r.part)+input('description','توضیحات',r.description)+
 select('warranty','گارانتی',[['','مشخص نشده'],['دارد','دارد'],['ندارد','ندارد']],r.warranty)+dateInput('requested','تاریخ درخواست',r.requested)+dateInput('finished','تاریخ اتمام',r.finished)+
 paymentFields(r,true)+fileField('فایل فاکتور خدمت'),id,`data-revision="${r.revision||0}" data-base="${esc(r.created||today())}" data-contract="${r.id||''}"`);
 syncFinancialForm($('#record-form'));
}
function deliverForm(id,cid){
 const k=data.buyers.find(b=>b.id===Number(id)).contracts.find(x=>x.id===Number(cid));
 recordForm('تحویل دستگاه','deliver',`<p class="full">موعد قراردادی: ${jalali(k.delivery)}</p>`+dateInput('actualDelivery','تاریخ تحویل واقعی *',k.actualDelivery||today(),true)+input('delayReason','علت تأخیر *',k.delayReason),id,`data-revision="${k.revision||0}" data-contract="${k.id}" data-due="${esc(k.delivery)}"`);
 syncDelivery($('#record-form'));
}
function syncDelivery(form){
 let late=false;try{late=fromJalali(form.elements.actualDelivery.value)>form.dataset.due;}catch{}
 const reason=form.elements.delayReason;reason.disabled=!late;reason.required=late;reason.parentElement.hidden=!late;
}
function serviceCard(b,r){
 return `<article class="device-summary"><h3>${esc(r.type)}</h3>${detailPairs([['قطعه',r.part],['توضیحات',r.description],['گارانتی',r.warranty],['درخواست',jalali(r.requested)],['اتمام',jalali(r.finished)]])}${receiptSummary(r)}${fileLink(r.file)}${canSell()?panelButton('service-edit','ویرایش خدمت',b.id,`data-contract="${r.id}"`):''}</article>`;
}

function contractForm(id,cid){
 const k=data.buyers.find(x=>x.id===Number(id)).contracts.find(x=>x.id===Number(cid))||{};
 recordForm('قرارداد خرید دستگاه','contract',dateInput('signed','تاریخ عقد قرارداد *',k.signed||today(),true)+dateInput('delivery','موعد تحویل *',k.delivery,true)+(k.actualDelivery?input('delayReason','علت تأخیر در صورت تحویل پس از موعد',k.delayReason):'')+input('accessories','لوازم جانبی',k.accessories)+paymentFields(k)+fileField('فایل قرارداد')+
 `<div class="full"><h3>دستگاه‌های خریداری‌شده</h3><div id="device-rows">${(k.devices?.length?k.devices:[{}]).map(d=>deviceRow(d,true)).join('')}</div>${panelButton('add-device','افزودن دستگاه',id)}</div>`,id,`data-revision="${k.revision||0}" data-contract="${k.id||''}"`);
 syncFinancialForm($('#record-form'));
}
function memberForm(id){
 const u=data.users.find(x=>x.id===Number(id));
 recordForm('ویرایش عضو تیم','member',input('name','نام و نام خانوادگی',u.name,'text',true)+input('username','نام کاربری',u.username,'text',true)+input('password','رمز جدید (اختیاری)','','password')+select('role','نقش',Object.entries(roles),u.role),id);
}
function weeklyPanel(){
 const weeks=data.weekly||[];
 return `<section class="panel weekly-panel"><h2>کارهای عقب‌افتاده در پایان هفته</h2><p>پایان جمعه به وقت تهران · فروش و فنی</p>${weeks.length?weeks.map((w,i)=>`<details ${i===0?'open':''}><summary>هفتهٔ منتهی به ${jalali(w.friday)}</summary>${w.owners.map(o=>`<details><summary>${esc(o.name)} · ${esc(roles[o.role])} · ${fa(o.tasks.length)} کار</summary>${o.tasks.map(t=>`<p>${esc(t.title)} · P-${String(t.customer_id).padStart(5,'0')} · موعد ${jalali(t.due)} · ${fa(t.days)} روز تأخیر</p>`).join('')||'کار عقب‌افتاده ندارد.'}</details>`).join('')}</details>`).join(''):'<p>اولین گزارش در پایان جمعهٔ پیش رو ثبت می‌شود.</p>'}</section>`;
}
function reportPage(){
 const ratio=(n,d)=>d?`${fa(n)} از ${fa(d)} (${fa(Math.round(100*n/d))}٪)`:'—';
 return heading('گزارش موفقیت فروش','هر درخواست با بازدید برگزارشده، یک بار شمرده می‌شود.')+
 `<div class="panel table-scroll"><table><thead><tr><th>کارشناس فروش</th><th>بازدید به کل متقاضیان</th><th>قرارداد به بازدید</th></tr></thead><tbody>${data.report.map(r=>`<tr><td>${esc(userName(r.id))}</td><td>${ratio(r.visits,r.total)}</td><td>${ratio(r.contracts,r.visits)}</td></tr>`).join('')}</tbody></table></div>`+weeklyPanel();
}
async function auditView(){
 const {audit}=await api('audit');
 showModal('سابقه تغییرات',`<section class="record-body">${audit.map(a=>`<details><summary>${esc(a.action)} · ${esc(a.entity)} ${fa(a.target)} · ${esc(a.author)} · ${jalali(a.created.slice(0,10))}</summary><p>پیش از تغییر</p><pre>${esc(JSON.stringify(JSON.parse(a.previous),null,2))}</pre><p>پس از تغییر</p><pre>${esc(JSON.stringify(JSON.parse(a.value),null,2))}</pre></details>`).join('')||'هنوز تغییری ثبت نشده است.'}</section>`,'detail-modal');
}
let shownEvents=[];
function stageForm(eventId){
 const e=shownEvents.find(x=>x.id===Number(eventId)),d=e.details,c=data.customers.find(x=>x.id===state.selected);
 let fields=d.discovery?discoveryFields({...c,readiness:d.readiness||c.readiness}):(d.readiness||d.kind==='followup')?select('readiness','میزان آمادگی خرید',[['','انتخاب کنید'],...Object.entries(readiness)],d.readiness||'',true):'';
 if(d.actualDate)fields+=dateInput('actualDate','تاریخ انجام',d.actualDate,true);
 if(d.nextTask)fields+=dateInput('nextDate','موعد پیگیری',d.nextDate||data.tasks.find(t=>t.id===d.nextTask)?.due,true);
 if(d.scheduledTask)fields+=dateInput('scheduledDate','تاریخ جلسه',d.scheduledDate,true)+input('time','ساعت جلسه',d.time,'time');
 if(d.kind==='quote')fields+=select('quoteStatus','وضعیت پیش‌فاکتور',Object.entries(quoteLabels),d.quoteStatus,true)+input('quoteNumber','شماره پیش‌فاکتور',d.quoteNumber)+dateInput('sentDate','تاریخ ارسال',d.sentDate||today());
 if(d.kind==='quote')fields+='<label>جایگزینی فایل پیش‌فاکتور<input type="file" name="upload"></label>';
 if(d.meetingResult&&d.meetingResult!=='signed')fields+=select('meetingResult','نتیجه جلسه',[['held','برگزار شد'],['cancelled','لغو شد'],['noShow','حاضر نشد']],d.meetingResult);
 recordForm('ویرایش '+esc(e.type),'stage',fields+note('توضیحات',d.note??e.note),e.id);
}
function readDevices(form){
 return $$('.device-row',form).map(row=>({tonnage:$('[name=deviceTonnage]',row).value,technicalFeatures:$('[name=deviceFeatures]',row).value,quotedPrice:$('[name=devicePrice]',row)?.value||'',build:$('[name=build]',row)?.value,customization:$('[name=customization]',row)?.value}));
}
async function saveRecord(form,b){
 const {kind,id,contract}=form.dataset;
 if(kind==='import')return importSheet(form);
 if(form.dataset.revision!==undefined)b.revision=Number(form.dataset.revision);
 if(kind==='buyer'){b.phone=digits(b.phone);const r=await api('buyers'+(+id?'/'+id:''),+id?'PUT':'POST',b);await load();buyerDetail(r.id);}
 if(['contract','service'].includes(kind)){serializePayment(form,b);b.attachment=await attachmentInput(form.elements.upload.files[0]);delete b.upload;}
 if(kind==='service'){await api(`buyers/${id}/services${contract?'/'+contract:''}`,contract?'PUT':'POST',b);await load();buyerDetail(id);}
 if(kind==='deliver'){await api(`buyers/${id}/contracts/${contract}/delivery`,'PUT',b);await load();buyerDetail(id);}
 if(kind==='contract'){b.devices=readDevices(form);await api(`buyers/${id}/contracts${contract?'/'+contract:''}`,contract?'PUT':'POST',b);await load();buyerDetail(id);}
 if(kind==='member'){await api('users/'+id,'PUT',b);modal.close();await load();}
 if(kind==='stage'){if(form.elements.upload){b.attachment=await attachmentInput(form.elements.upload.files[0]);delete b.upload;}if($('#device-rows',form))b.devices=readDevices(form);await api('customers/'+state.selected+'/actions','POST',{...b,type:'editStage',eventId:Number(id)});await load();await customerDetail(state.selected);}
 toast('تغییرات ذخیره شد.');
}
async function attachmentInput(file){
 if(!file?.size)return;
 if(file.size>5*1024*1024)throw Error('حداکثر اندازه فایل ۵ مگابایت است.');
 const data=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result.split(',')[1]);r.onerror=()=>reject(Error('خواندن فایل ممکن نشد.'));r.readAsDataURL(file);});
 return {name:file.name,data};
}

document.addEventListener('click',async e=>{const btn=e.target.closest('[data-action]');if(!btn)return;const a=btn.dataset.action;try{
 if(a==='refresh'){await load();toast('اطلاعات تیم به‌روز شد.');}
 else if(a==='navigate'){state.page=btn.dataset.page;render();}
 else if(a==='buyer')buyerDetail(btn.dataset.id);
 else if(a==='buyer-edit'||a==='buyer-new')buyerForm(Number(btn.dataset.id)||0);
 else if(a==='contract-new'||a==='contract-edit')contractForm(btn.dataset.id,btn.dataset.contract);
 else if(a==='service-new'||a==='service-edit')serviceForm(btn.dataset.id,btn.dataset.contract);
 else if(a==='deliver')deliverForm(btn.dataset.id,btn.dataset.contract);
 else if(a==='add-check'){const rows=$('.checks',modal);if(rows.children.length>=100)throw Error('حداکثر ۱۰۰ چک');rows.insertAdjacentHTML('beforeend',checkRow());syncFinancialForm(btn.form);}
 else if(a==='remove-check')btn.closest('.check-row').remove();
 else if(a==='member-edit')memberForm(btn.dataset.id);
 else if(a==='audit')await auditView();
 else if(a==='stage-edit')stageForm(btn.dataset.id);
 else if(a==='repeat'){const r=await api('buyers/'+btn.dataset.id+'/repeat','POST',{});await load();await customerDetail(r.customer.id);}
 else if(a==='member-delete'||a==='delete-lead'){if(!confirm(a==='delete-lead'?'متقاضی و تمام پیگیری‌های این پرونده حذف شوند؟':'این عضو از تیم حذف شود؟'))return;await api((a==='member-delete'?'users/':'customers/')+btn.dataset.id,'DELETE');modal.close();await load();toast('حذف انجام شد.');}
 else if(a==='new-customer')customerForm();
 else if(a==='add-device'){if($$('.device-row',modal).length>=30)throw Error('حداکثر ۳۰ دستگاه قابل ثبت است.');$('#device-rows').insertAdjacentHTML('beforeend',deviceRow({},Boolean($('#record-form[data-kind=contract]',modal))));syncFinancialForm(btn.form);}
 else if(a==='remove-device'){const row=btn.closest('.device-row');if($$('.device-row',modal).length>1)row.remove();else toast('حداقل یک دستگاه باید باقی بماند.',true);}
 else if(a==='customer')await customerDetail(btn.dataset.id);
 else if(a==='edit-customer')customerForm(data.customers.find(c=>c.id===Number(btn.dataset.id)));
 else if(a==='close-modal')dismissModal();
 else if(a==='task-tab'){state.taskFilter=btn.dataset.tab;render();}
 else if(a==='new-user')newUser();
 else if(a==='action-form')actionForm(btn.dataset.type);
 else if(a==='task'){const t=data.tasks.find(t=>t.id===Number(btn.dataset.id));state.selected=t.customer_id;if(t.kind==='profile')buyerDetail(data.customers.find(c=>c.id===t.customer_id).buyerId);else actionForm('complete',t.id);}
 else if(a==='reschedule')actionForm('reschedule',btn.dataset.id);
 else if(a==='export'||a==='template')exportCSV(btn.dataset.sheet,a==='template');
 else if(a==='import')importForm(btn.dataset.sheet);
 else if(a==='calendar')openCalendar(btn.parentElement.querySelector('input'));
 else if(a==='cal-prev'||a==='cal-next'){calM+=a==='cal-next'?1:-1;if(calM===0){calM=12;calY--;}if(calM===13){calM=1;calY++;}if(calY<1300||calY>1550){calY=Math.min(1550,Math.max(1300,calY));}renderCalendar();}
 else if(a==='cal-pick'){calendarTarget.value=jalali(btn.dataset.date);calendar.close();calendarTarget.dispatchEvent(new Event('change',{bubbles:true}));}
 else if(a==='cal-close')calendar.close();
 else if(a==='logout'){await api('logout','POST',{});currentUser=null;needsSetup=false;auth();}
 }catch(err){toast(err.message,true);}});
document.addEventListener('input',e=>{if(e.target.name==='total'&&e.target.form?.elements.payment?.value==='صندوق')syncFinancialForm(e.target.form);if(e.target.name==='devicePrice')e.target.nextElementSibling.textContent=priceLabel(e.target.value);if(e.target.id==='buyer-search')$('#buyer-results').innerHTML=buyerTable(e.target.value);if(e.target.id==='search'){state.search=e.target.value;$('#customer-results').innerHTML=customerTable(filteredCustomers());$('.result-count').textContent=fa(filteredCustomers().length)+' متقاضی خرید';}});
document.addEventListener('change',e=>{if(['payment','build','status','advance','fundAdvanceStatus','signed','requested','total'].includes(e.target.name)&&e.target.form?.id==='record-form')syncFinancialForm(e.target.form);if(e.target.name==='actualDelivery'&&e.target.form?.dataset.kind==='deliver')syncDelivery(e.target.form);if(e.target.name==='source'){const ref=e.target.form.querySelector('[name=referrer]');ref.closest('label').hidden=ref.disabled=e.target.value!=='معرف';ref.required=!ref.disabled;}if(e.target.dataset.filter){state[e.target.dataset.filter]=e.target.value;render();}if(e.target.id==='mine'){state.tasksMine=e.target.checked;render();}if(e.target.name==='result'&&$('#discovery-fields')){$('#discovery-fields').hidden=e.target.value!=='success';$('#discovery-fields').disabled=e.target.value!=='success';}});
document.addEventListener('submit',async e=>{e.preventDefault();const form=e.target;if(!['auth-form','customer-form','action-form','user-form','record-form'].includes(form.id))return;const button=$('[type="submit"]',form)||$('button.primary',form),error=$('.form-error',form);error.textContent='';button.disabled=true;try{
 const b=Object.fromEntries(new FormData(form));for(const field of form.querySelectorAll('.jdate'))if(!field.matches(':disabled'))b[field.name]=fromJalali(field.value);
 if(form.id==='record-form'){await saveRecord(form,b);return;}
 if($('#device-rows',form)&&b.result==='success')b.devices=readDevices(form);
 if(form.elements.upload){b.attachment=await attachmentInput(form.elements.upload.files[0]);delete b.upload;}
 if(form.id==='auth-form'){await api(needsSetup?'setup':'login','POST',b);await load();}
 else if(form.id==='customer-form'){const id=form.dataset.id;const result=await api('customers'+(id?'/'+id:''),id?'PUT':'POST',b);modal.close();await load();toast(id?'اطلاعات متقاضی خرید به‌روز شد.':`متقاضی خرید با کد ${result.customer.code} ثبت و به ${userName(result.customer.salesId)} تخصیص داده شد.`);if(data.customers.some(c=>c.id===result.customer.id))await customerDetail(result.customer.id);}
 else if(form.id==='user-form'){await api('users','POST',b);modal.close();await load();toast('همکار جدید به تیم اضافه شد.');}
 else {b.type=form.dataset.type;if(form.dataset.task)b.taskId=Number(form.dataset.task);const id=form.dataset.customer;await api(`customers/${id}/actions`,'POST',b);modal.close();await load();toast(currentUser.role==='technical'?'پاسخ ثبت شد و پرونده به کارشناس فروش برگشت.':'اقدام شما در پرونده ثبت شد.');if(data.customers.some(c=>c.id===Number(id)))await customerDetail(id);}
 }catch(err){error.textContent=err.message;}finally{button.disabled=false;}});
for(const d of [modal,calendar])d.addEventListener('click',e=>{if(e.target===d){const rect=d.getBoundingClientRect();if(e.clientX<rect.left||e.clientX>rect.right||e.clientY<rect.top||e.clientY>rect.bottom){if(d===modal)dismissModal();else d.close();}}});
window.addEventListener('hashchange',()=>{const p=location.hash.slice(1);if(currentUser&&rolePages().includes(p)){state.page=p;render();}});
async function boot(){try{const s=await api('session');currentUser=s.user;needsSetup=s.needsSetup;if(currentUser)await load();else auth();}catch(e){app.innerHTML=`<div class="loading"><h1>ارتباط با سرور برقرار نشد</h1><p>${esc(e.message)}</p><button class="primary" id="retry">تلاش دوباره</button></div>`;$('#retry').addEventListener('click',boot);}}
boot();
