// Excel UTF-8 CSV (including quoted multiline fields) and the first sheet of .xlsx.
export function parseCSV(source){
 const text=source.replace(/^\uFEFF/,'');
 const separator=(text.split(/\r?\n/,1)[0].includes(',')?',':';');
 const rows=[];let row=[],value='',quoted=false;
 for(let i=0;i<text.length;i++){
   const c=text[i];
   if(c==='"'){
     if(quoted&&text[i+1]==='"'){value+='"';i++;}
     else quoted=!quoted;
   }else if(!quoted&&c===separator){row.push(value);value='';}
   else if(!quoted&&(c==='\n'||c==='\r')){if(c==='\r'&&text[i+1]==='\n')i++;row.push(value);rows.push(row);row=[];value='';}
   else value+=c;
 }
 if(quoted)throw Error('نقل‌قول بسته‌نشده در فایل CSV.');
 if(row.length||value)rows.push([...row,value]);
 return rows;
}
export async function readSheet(file){
 if(!file||file.size>5*1024*1024)throw Error('فایل حداکثر ۵ مگابایت را انتخاب کنید.');
 if(/\.csv$/i.test(file.name))return parseCSV(await file.text());
 if(!/\.xlsx$/i.test(file.name))throw Error('فرمت فایل باید CSV یا XLSX باشد.');
 const bytes=new Uint8Array(await file.arrayBuffer()),dv=new DataView(bytes.buffer);
 const u16=i=>dv.getUint16(i,true),u32=i=>dv.getUint32(i,true),decoder=new TextDecoder();
 let end=bytes.length-22;
 while(end>=0&&end>=bytes.length-65557&&u32(end)!==0x06054b50)end--;
 if(end<0||u32(end)!==0x06054b50)throw Error('ساختار فایل اکسل معتبر نیست.');
 const entries=new Map();
 for(let i=u32(end+16),n=0;n<u16(end+10);n++){
   if(u32(i)!==0x02014b50)throw Error('فایل اکسل ناقص است.');
   const name=decoder.decode(bytes.subarray(i+46,i+46+u16(i+28)));
   entries.set(name,{offset:u32(i+42),size:u32(i+20),method:u16(i+10)});
   i+=46+u16(i+28)+u16(i+30)+u16(i+32);
 }
 async function xml(name){
   const e=entries.get(name);if(!e)throw Error('کاربرگ اکسل پیدا نشد.');
   const start=e.offset+30+u16(e.offset+26)+u16(e.offset+28),chunk=bytes.subarray(start,start+e.size);
   let stream=new Blob([chunk]).stream();
   if(e.method===8)stream=stream.pipeThrough(new DecompressionStream('deflate-raw'));
   else if(e.method!==0)throw Error('نوع فشرده‌سازی فایل اکسل پشتیبانی نمی‌شود.');
   const reader=stream.getReader(),parts=[];let size=0;
   while(true){const r=await reader.read();if(r.done)break;size+=r.value.length;if(size>10*1024*1024){await reader.cancel();throw Error('کاربرگ بیش از حد بزرگ است.');}parts.push(r.value);}
   const source=await new Blob(parts).text();
   if(/<!DOCTYPE/i.test(source))throw Error('ساختار XML پشتیبانی نمی‌شود.');
   const doc=new DOMParser().parseFromString(source,'application/xml');
   if(doc.querySelector('parsererror'))throw Error('ساختار XML معتبر نیست.');
   return doc;
 }
 const all=(e,tag)=>Array.from(e.getElementsByTagNameNS('*',tag));
 const book=await xml('xl/workbook.xml'),sheet=all(book,'sheet')[0];
 const rels=all(await xml('xl/_rels/workbook.xml.rels'),'Relationship');
 const target=rels.find(r=>r.getAttribute('Id')===sheet?.getAttribute('r:id'))?.getAttribute('Target');
 if(!target)throw Error('کاربرگ اول پیدا نشد.');
 const doc=await xml(new URL(target,'https://local/xl/workbook.xml').pathname.slice(1));
 const strings=entries.has('xl/sharedStrings.xml')?all(await xml('xl/sharedStrings.xml'),'si').map(s=>all(s,'t').map(x=>x.textContent).join('')):[];
 const rows=all(doc,'row').map(r=>{
   const row=[];
   for(const c of all(r,'c')){
     const letters=c.getAttribute('r')?.match(/^[A-Z]+/)?.[0]||'A';
     const col=[...letters].reduce((n,l)=>26*n+l.charCodeAt(0)-64,0)-1;
     if(col>100)continue;
     const value=all(c,'v')[0]?.textContent||'';
     row[col]=c.getAttribute('t')==='s'?strings[Number(value)]||'':c.getAttribute('t')==='inlineStr'?all(c,'t').map(t=>t.textContent).join(''):value;
   }
   return row;
 });
 rows.epoch1904=['1','true'].includes(all(book,'workbookPr')[0]?.getAttribute('date1904'));
 return rows;
}
