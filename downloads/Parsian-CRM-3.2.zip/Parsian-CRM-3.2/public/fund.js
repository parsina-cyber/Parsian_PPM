// Three Persian calendar months, clamping the day when the target month is shorter.
const calendar=new Intl.DateTimeFormat('en-US-u-ca-persian',{year:'numeric',month:'numeric',day:'numeric',timeZone:'UTC'});
function persianParts(day){
  const parts=Object.fromEntries(calendar.formatToParts(day).map(p=>[p.type,Number(p.value)]));
  return {month:parts.year*12+parts.month-1,day:parts.day};
}
export function fundSchedule(total,base){
  const start=Date.parse(base+'T00:00:00Z'),from=persianParts(start);
  let due;
  for(let days=85;days<=94;days++){
    const time=start+days*86400000,part=persianParts(time);
    if(part.month>from.month+3)break;
    if(part.month===from.month+3){
      due=new Date(time).toISOString().slice(0,10);
      if(part.day>=from.day)break;
    }
  }
  const advance=Math.round(total*0.3);
  return {advance,balance:total-advance,due};
}
